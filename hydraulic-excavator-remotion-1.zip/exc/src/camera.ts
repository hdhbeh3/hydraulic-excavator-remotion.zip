// Camera director. Every shot orbits an anchor point computed from the live machine pose, so framing stays
// correct no matter how the machine moves. az=0 -> camera on +z side (machine front points screen-right).
import { anchors, V3, lerp3 } from './world';
import { lerp, smooth, smoother, clamp } from './timeline';

export interface Shot {
  t0: number; t1: number;
  a: string; b?: string; mix?: [number, number]; // anchor A, optional anchor B and blend window (0..1 of shot)
  az: [number, number]; el: [number, number]; d: [number, number]; fov: [number, number];
  sy?: number; sx?: number; whip?: boolean; ease?: 'smooth' | 'linear' | 'smoother';
}
const S = (t0: number, t1: number, a: string, az: [number, number], el: [number, number], d: [number, number], fov: [number, number], o: Partial<Shot> = {}): Shot =>
  ({ t0, t1, a, az, el, d, fov, ...o });

export const SHOTS: Shot[] = [
  // ---- SCENE 1: tabletop syringe (units: 1 = ~10 cm)
  S(0, 1.81, 'tableSyringeA', [28, -8], [9, 13], [11.5, 10.2], [30, 28], { sy: 0.12, sx: 0.0 }),
  S(1.81, 3.97, 'tableSyringeA', [-30, -52], [10, 6], [3.6, 3.0], [28, 26], { b: 'tableMid', mix: [0.0, 1] }),
  S(3.97, 6.31, 'tableMid', [14, 6], [26, 20], [8.2, 7.2], [32, 30]),
  S(6.31, 8.55, 'tableSyringeA', [12, 8], [14, 10], [6.2, 5.0], [30, 30], { b: 'tableB', mix: [0.1, 0.9] }),
  S(8.55, 11.33, 'tableB', [10, 4], [8, 1], [6, 24], [30, 36], { ease: 'smoother' }),
  // ---- SCENE 2: excavator reveal and the problem
  S(11.33, 14.73, 'boomCylMid', [8, 62], [6, 14], [3.4, 21], [34, 36], { b: 'workArea', mix: [0.18, 0.75], ease: 'smoother' }),
  S(14.73, 15.6, 'rock', [58, 80], [4, 6], [9, 6.5], [32, 30], { whip: true }),
  S(15.6, 16.51, 'rock', [80, 70], [6, 8], [6.5, 5.2], [30, 30]),
  S(16.51, 19.17, 'boomCylMid', [38, 30], [6, 8], [3.0, 2.2], [30, 28]),
  S(19.17, 21.09, 'house', [-55, -30], [12, 18], [15, 7], [34, 32], { b: 'engine', mix: [0, 1] }),
  // ---- SCENE 3: engine, pump, circuit
  S(21.09, 23.18, 'engine', [-38, -8], [14, 18], [4.6, 3.8], [30, 30]),
  S(23.18, 24.7, 'tank', [30, 52], [18, 24], [3.8, 3.4], [30, 30], { b: 'pump', mix: [0.2, 1] }),
  S(24.7, 26.6, 'pump', [52, 64], [24, 30], [3.4, 4.4], [30, 32], { b: 'valve', mix: [0.0, 1] }),
  // ---- SCENE 4: cylinders and movements
  S(26.6, 28.08, 'valve', [26, 14], [22, 10], [4.4, 2.8], [32, 30], { b: 'boomCylMid', mix: [0.1, 1] }),
  S(28.08, 29.76, 'boomCylMid', [6, 2], [2, 3], [2.5, 2.2], [30, 30]),
  S(29.76, 32.51, 'boomCylMid', [6, 36], [3, 14], [3.0, 17], [30, 36], { b: 'workArea', mix: [0.0, 0.8], ease: 'smoother' }),
  S(32.51, 34.5, 'bucketTip', [52, 74], [8, 6], [11, 9], [34, 32]),
  S(34.5, 36.17, 'stickCylMid', [24, -8], [10, 6], [4.2, 3.4], [30, 30]),
  S(36.17, 37.6, 'bktCylMid', [14, -14], [8, 6], [3.4, 3.0], [30, 30]),
  S(37.6, 41.2, 'workArea', [22, 96], [10, 17], [15, 20], [36, 36], { ease: 'linear' }),
  // ---- SCENE 5: counterweight
  S(41.2, 43.28, 'bucketTip', [72, 56], [5, 8], [8.5, 8.0], [32, 32]),
  S(43.28, 44.88, 'bucketTip', [86, 62], [4, 6], [7.5, 14], [32, 34], { b: 'house', mix: [0.2, 1] }),
  S(44.88, 47.17, 'undercarriage', [2, 4], [2, 3], [13, 11.5], [34, 32]),
  S(47.17, 49.61, 'counterweight', [-6, -112], [6, 10], [10, 5.6], [34, 32], { ease: 'smoother' }),
  S(49.61, 51.86, 'undercarriage', [4, 22], [3, 6], [13.5, 13], [34, 34]),
  // ---- SCENE 6: tracks
  S(51.86, 53.24, 'trackFront', [34, 62], [4, 3], [6.4, 4.2], [32, 30]),
  S(53.24, 55.0, 'motorL', [168, 175], [6, 4], [3.2, 2.4], [30, 28], { whip: true }),
  S(55.0, 56.4, 'sprocketL', [170, 140], [6, 7], [2.4, 6.5], [28, 32], { b: 'trackL', mix: [0, 1] }),
  S(56.4, 58.21, 'house', [28, 62], [6, 9], [14, 15.5], [34, 34]),
  // ---- SCENE 7: joysticks and payoff
  S(58.21, 58.9, 'joysticks', [-70, -82], [30, 26], [1.45, 1.3], [38, 36], { sy: 0.1 }),
  S(58.9, 59.8, 'bucketTip', [66, 54], [3, 4], [7.5, 6.5], [32, 32]),
  S(59.8, 60.9, 'joysticks', [-95, -82], [24, 28], [1.35, 1.25], [36, 36], { sy: 0.1 }),
  S(60.9, 61.6, 'joysticks', [-80, -60], [20, 16], [1.5, 1.3], [38, 36], { sy: 0.1 }),
  S(61.6, 63.13, 'bucketTip', [50, 70], [8, 6], [10, 8.5], [34, 32]),
  S(63.13, 64.99, 'valve', [18, 52], [28, 34], [3.4, 3.0], [32, 30], { b: 'joysticks', mix: [0.9, 1] }),
  S(64.99, 66.7, 'workArea', [70, 118], [8, 10], [16, 19], [34, 34]),
  S(66.7, 69.79, 'workArea', [118, 156], [10, 24], [19, 36], [34, 38], { ease: 'smoother' }),
];

export interface Cam { pos: V3; target: V3; fov: number; blur: number; shot: number }

export function cameraAt(t: number): Cam {
  let idx = SHOTS.findIndex(s => t >= s.t0 && t < s.t1);
  if (idx < 0) idx = t < SHOTS[0].t0 ? 0 : SHOTS.length - 1;
  const s = SHOTS[idx];
  const u0 = clamp((t - s.t0) / (s.t1 - s.t0));
  const u = s.ease === 'linear' ? u0 : s.ease === 'smoother' ? smoother(u0) : smooth(u0);
  const A = anchors(t);
  let tgt: V3 = [...A[s.a]] as V3;
  if (s.b && s.mix) tgt = lerp3(tgt, A[s.b], smooth((u0 - s.mix[0]) / (s.mix[1] - s.mix[0])));
  if (tgt[0] > -50) tgt[1] = Math.max(tgt[1], 0.45); // never aim below the ground plane
  const az = (lerp(s.az[0], s.az[1], u) * Math.PI) / 180, el = (lerp(s.el[0], s.el[1], u) * Math.PI) / 180;
  const d = lerp(s.d[0], s.d[1], u), fov = lerp(s.fov[0], s.fov[1], u);
  const off: V3 = [Math.sin(az) * Math.cos(el) * d, Math.sin(el) * d, Math.cos(az) * Math.cos(el) * d];
  let pos: V3 = [tgt[0] + off[0], tgt[1] + off[1], tgt[2] + off[2]];
  // never dip below the ground (tabletop scene has its own floor at y=0 too)
  pos[1] = Math.max(pos[1], tgt[1] > 0.3 ? 0.35 : 0.2);
  // screen-space shift: keep subject in the Shorts-safe upper-left area (clear of bottom caption/UI and right-hand buttons)
  const f: V3 = [tgt[0] - pos[0], tgt[1] - pos[1], tgt[2] - pos[2]];
  const fl = Math.hypot(f[0], f[1], f[2]);
  const fn: V3 = [f[0] / fl, f[1] / fl, f[2] / fl];
  // right = normalize(forward x worldUp) with worldUp=(0,1,0): (fy*0 - fz*1, fz*0 - fx*0, fx*1 - fy*0) = (-fz, 0, fx)
  const rl = Math.hypot(fn[2], fn[0]) || 1;
  const r: V3 = [-fn[2] / rl, 0, fn[0] / rl];
  // up = right x forward
  const up: V3 = [r[1] * fn[2] - r[2] * fn[1], r[2] * fn[0] - r[0] * fn[2], r[0] * fn[1] - r[1] * fn[0]];
  const halfH = Math.tan((fov * Math.PI) / 360) * fl, halfW = halfH * (1080 / 1920);
  const sy = s.sy ?? 0.17, sx = s.sx ?? 0.05; // sy: subject moves UP by sy*halfH; sx: subject moves LEFT by sx*halfW
  const aim: V3 = [
    tgt[0] - up[0] * halfH * sy + r[0] * halfW * sx,
    tgt[1] - up[1] * halfH * sy + r[1] * halfW * sx,
    tgt[2] - up[2] * halfH * sy + r[2] * halfW * sx,
  ];
  // motion blur strength (px) for whip pans and fast moves only
  const blur = s.whip ? 7 * Math.max(0, 1 - Math.abs(u0 - 0.06) / 0.16) : 0;
  return { pos, target: aim, fov, blur, shot: idx };
}
