import React, { useMemo } from 'react';
import * as THREE from 'three';
import { M, box, rbox, cyl, sph, Seg, UNIT_CYL, smoothPath } from './common';
import { TABLE, V3 } from '../world';
import { ramp, smoother, smooth } from '../timeline';

const X = Math.PI / 2;
const PLUNGER_BLUE = new THREE.MeshStandardMaterial({ color: '#3186e8', metalness: 0.08, roughness: 0.32 });
const NEEDLE_STEEL = new THREE.MeshStandardMaterial({ color: '#d9e1e8', metalness: 0.92, roughness: 0.18 });
const LC = 2.2; // barrel interior length (1 unit = 10 cm)
const stopperX = (q: number) => 0.25 + q * (LC - 0.25 - 0.3);

/** Transparent syringe along +x (open back at x=0, nozzle at x~2.55). q: plunger travel 0 (pulled back) .. 1 (pushed in). */
export function Syringe({ q, liquid }: { q: number; liquid: THREE.Material }) {
  const xs = stopperX(q);
  const ticks = Array.from({ length: 11 }, (_, k) => k);
  const lq = Math.max(LC - (xs + 0.1), 0.001);
  return (
    <group>
      <mesh geometry={cyl(0.22, 0.22, LC, 32, true)} material={M.plastic} position={[LC / 2, 0, 0]} rotation={[0, 0, X]} />
      <mesh geometry={cyl(0.07, 0.22, 0.25, 24)} material={M.plastic} position={[LC + 0.125, 0, 0]} rotation={[0, 0, -X]} />
      <mesh geometry={cyl(0.07, 0.07, 0.22, 16)} material={M.plastic} position={[LC + 0.36, 0, 0]} rotation={[0, 0, X]} />
      <mesh geometry={cyl(0.09, 0.09, 0.05, 16)} material={M.plastic} position={[LC + 0.47, 0, 0]} rotation={[0, 0, X]} />
      <mesh geometry={rbox(0.06, 0.3, 0.95, 0.02)} material={M.plastic} position={[0.03, 0, 0]} />
      {ticks.map(k => <mesh key={k} geometry={box(0.012, 0.008, k % 5 === 0 ? 0.2 : 0.1)} material={M.rubber} position={[0.35 + k * 0.17, 0.222, 0]} />)}
      <mesh geometry={cyl(0.205, 0.205, 0.06, 24)} material={M.rubber} position={[xs - 0.07, 0, 0]} rotation={[0, 0, X]} />
      <mesh geometry={cyl(0.21, 0.21, 0.05, 24)} material={M.rubber} position={[xs + 0.03, 0, 0]} rotation={[0, 0, X]} />
      <mesh geometry={box(2.3, 0.05, 0.18)} material={M.white} position={[xs - 0.1 - 1.15, 0, 0]} />
      <mesh geometry={box(2.3, 0.18, 0.05)} material={M.white} position={[xs - 0.1 - 1.15, 0, 0]} />
      <mesh geometry={cyl(0.34, 0.34, 0.07, 28)} material={PLUNGER_BLUE} position={[xs - 2.4, 0, 0]} rotation={[0, 0, X]} />
      <mesh geometry={UNIT_CYL} material={liquid} position={[xs + 0.06 + lq / 2, 0, 0]} rotation={[0, 0, X]} scale={[0.205, lq, 0.205]} />
      {q < 0.99 && <mesh geometry={cyl(0.065, 0.2, 0.23, 20)} material={liquid} position={[LC + 0.125, 0, 0]} rotation={[0, 0, -X]} />}
      <mesh geometry={cyl(0.018, 0.018, 0.34, 12)} material={NEEDLE_STEEL} position={[LC + 0.55, 0, 0]} rotation={[0, 0, X]} />
    </group>
  );
}

let woodTex: THREE.CanvasTexture | null = null;
function wood(): THREE.CanvasTexture {
  if (woodTex) return woodTex;
  const c = document.createElement('canvas'); c.width = 1024; c.height = 512; const g = c.getContext('2d')!;
  g.fillStyle = '#7a5230'; g.fillRect(0, 0, 1024, 512);
  let s = 7; const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let i = 0; i < 260; i++) { const y = rnd() * 512; g.strokeStyle = `rgba(${40 + rnd() * 40},${20 + rnd() * 25},${8 + rnd() * 12},${0.12 + rnd() * 0.25})`; g.lineWidth = 0.6 + rnd() * 2.2; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= 1024; x += 64) g.lineTo(x, y + Math.sin(x * 0.01 + i) * 4 + (rnd() - 0.5) * 2); g.stroke(); }
  for (let i = 0; i < 8; i++) { g.strokeStyle = 'rgba(30,15,5,0.5)'; g.lineWidth = 2; const x = i * 128 + 20; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 512); g.stroke(); }
  woodTex = new THREE.CanvasTexture(c); woodTex.wrapS = woodTex.wrapT = THREE.RepeatWrapping; woodTex.repeat.set(3, 2); woodTex.colorSpace = THREE.SRGBColorSpace;
  return woodTex;
}
const woodMat = () => new THREE.MeshStandardMaterial({ map: wood(), roughness: 0.55, metalness: 0.0 });

const BOKEH = Array.from({ length: 16 }, (_, i) => ({ x: -22 + ((i * 37) % 44), y: 3 + ((i * 53) % 12), z: -30 - ((i * 29) % 16), r: 1.0 + ((i * 17) % 20) / 8, c: i % 3 === 0 ? '#ffb45c' : i % 3 === 1 ? '#ffd9a0' : '#7fb4ff' }));

export function SyringeScene({ t }: { t: number }) {
  const tex = useMemo(() => woodMat(), []);
  const bokeh = useMemo(() => BOKEH.map(b => new THREE.MeshBasicMaterial({ color: b.c, transparent: true, opacity: 0.2, depthWrite: false, fog: false })), []);
  const ax = TABLE[0] - 3.2, bx = TABLE[0] + 0.65, y = 0.24;
  const single = t < 3.95;
  const qSingle = 0.15 + 0.6 * ramp(t, 1.95, 3.4);
  const qA = 0.2 + 0.6 * (ramp(t, 6.55, 7.75) - ramp(t, 7.95, 8.5) + ramp(t, 9.0, 10.8));
  const qB = 1 - qA;
  const A = single ? qSingle : qA;
  const grow = smoother((t - 8.7) / 1.6);
  const sB = 1 + 3.5 * grow, rot = (Math.PI / 2) * grow;
  const slide = 8 * (1 - smoother((t - 3.97) / 0.7));
  const showB = t >= 3.95;
  const tubeP = ramp(t, 4.4, 5.1);
  const liquidA = M.blueOil;
  const tipA: V3 = [ax + 2.55, y, 0], tipB: V3 = [bx, y, 0];
  const tubePts = useMemo(() => smoothPath([tipA, [tipA[0] + 0.5, y + 0.1, 0.0], [tipA[0] + 0.9, y + 1.0, 0.15], [(tipA[0] + tipB[0]) / 2, y + 1.3, 0.2], [tipB[0] - 0.9, y + 1.0, 0.15], [tipB[0] - 0.5, y + 0.1, 0], tipB], 24), []); // eslint-disable-line
  const n = Math.max(2, Math.round(tubePts.length * tubeP));
  const xsB = stopperX(qB);
  const axis = 4.95 - xsB; // rod end distance from nozzle along the syringe axis
  const top: V3 = [bx + axis * sB * Math.cos(rot), y + axis * sB * Math.sin(rot), 0];
  const carK = smoother((t - 10.55) / 0.4);
  const drops = single && qSingle > 0.62 && t < 3.6;
  return (
    <group>
      <mesh geometry={box(70, 1, 36)} material={tex} position={[TABLE[0], -0.5, 0]} receiveShadow />
      {BOKEH.map((b, i) => <mesh key={i} geometry={sph(b.r, 12, 8)} material={bokeh[i]} position={[TABLE[0] + b.x, b.y, b.z]} />)}
      <group position={[ax, y, 0]}><Syringe q={A} liquid={liquidA} /></group>
      {drops && [0, 1, 2].map(i => { const u = (t * 2.2 + i / 3) % 1; return <mesh key={i} geometry={sph(0.045, 8, 6)} material={M.orangeLiquid} position={[ax + 3.05 + 0.1 * u, y - 0.05 - 0.2 * u * u, 0]} scale={[1, 1 + u, 1]} />; })}
      {showB && <>
        <group position={[bx + slide, y, 0]} rotation={[0, 0, rot]} scale={[sB, sB, sB]}>
          <group rotation={[0, Math.PI, 0]}><group position={[-(2.55), 0, 0]}><Syringe q={qB} liquid={M.blueOil} /></group></group>
        </group>
        {slide < 0.05 && tubePts.slice(1, n).map((p, i) => <React.Fragment key={i}>
          <Seg a={tubePts[i]} b={p} r={0.075} mat={M.plastic} cast={false} />
          {tubeP > 0.9 && t > 5.0 && <Seg a={tubePts[i]} b={p} r={0.055} mat={M.blueOil} cast={false} />}
        </React.Fragment>)}
        {carK > 0.01 && <group position={[top[0], top[1] + 0.25 * sB * 0.1, 0]} scale={[carK, carK, carK]}>
          <mesh geometry={rbox(8, 0.5, 4, 0.1)} material={M.steel} position={[0, 0.25, 0]} castShadow />
          <Car />
        </group>}
      </>}
    </group>
  );
}
function Car() {
  return (
    <group position={[0, 0.5, 0]}>
      <mesh geometry={rbox(6.2, 1.1, 2.7, 0.35)} material={M.red} position={[0, 0.95, 0]} castShadow />
      <mesh geometry={rbox(3.2, 1.0, 2.4, 0.3)} material={M.red} position={[-0.3, 1.95, 0]} castShadow />
      <mesh geometry={box(2.6, 0.7, 2.44)} material={M.glass} position={[-0.3, 1.98, 0]} />
      {[[-2, 1.2], [2, 1.2], [-2, -1.2], [2, -1.2]].map(([x, z], i) => <group key={i} position={[x, 0.55, z]}>
        <mesh geometry={cyl(0.6, 0.6, 0.45, 20)} material={M.rubber} rotation={[X, 0, 0]} castShadow />
        <mesh geometry={cyl(0.32, 0.32, 0.47, 16)} material={M.chrome} rotation={[X, 0, 0]} /></group>)}
      <mesh geometry={box(0.1, 0.3, 0.5)} material={M.white} position={[3.1, 1.0, 0.8]} />
      <mesh geometry={box(0.1, 0.3, 0.5)} material={M.white} position={[3.1, 1.0, -0.8]} />
    </group>
  );
}

/** Tiny syringe gag: it pushes against the boom cylinder; nothing moves. */
export function TinySyringe({ t, pos }: { t: number; pos: V3 }) {
  const q = 0.2 + 0.7 * ramp(t, 17.0, 18.3);
  return <group position={pos} rotation={[0, -0.5, -0.45]} scale={[0.1, 0.1, 0.1]}><Syringe q={q} liquid={M.blueOil} /></group>;
}
