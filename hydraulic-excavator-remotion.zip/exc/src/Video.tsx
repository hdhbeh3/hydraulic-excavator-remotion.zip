import React, { useLayoutEffect, useMemo } from 'react';
import { AbsoluteFill, Audio, staticFile, useCurrentFrame } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { FPS, WIDTH, HEIGHT, ramp, clamp, poseAt } from './timeline';
import { cameraAt } from './camera';
import { anchors, machineAt, groundH, TABLE, PILE_A, PILE_B, V3 } from './world';
import { cutsAt, flowsAt } from './cutaways';
import { Excavator, RockMesh } from './world/Excavator';
import { Site } from './world/Site';
import { SyringeScene, TinySyringe } from './world/Syringes';
import { Dust, Falling } from './world/Effects';

function Env() {
  const { gl, scene } = useThree();
  useLayoutEffect(() => {
    const pm = new THREE.PMREMGenerator(gl);
    const tex = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = tex;
    return () => { tex.dispose(); pm.dispose(); };
  }, [gl, scene]);
  return null;
}

function Rig({ t }: { t: number }) {
  const { camera, invalidate } = useThree();
  const c = cameraAt(t);
  const cam = camera as THREE.PerspectiveCamera;
  // set during render so the camera is correct before R3F draws this frame
  cam.position.set(c.pos[0], c.pos[1], c.pos[2]);
  cam.fov = c.fov; cam.near = c.pos[0] < -50 ? 0.05 : 0.1; cam.far = 1500; cam.aspect = WIDTH / HEIGHT;
  cam.lookAt(c.target[0], c.target[1], c.target[2]);
  cam.updateProjectionMatrix(); cam.updateMatrixWorld();
  useLayoutEffect(() => { invalidate(); });
  return null;
}

function Sun({ target, offset, intensity, color, size = 18 }: { target: V3; offset: V3; intensity: number; color: string; size?: number }) {
  const obj = useMemo(() => new THREE.Object3D(), []);
  return (
    <group>
      <primitive object={obj} position={target} />
      <directionalLight target={obj} position={[target[0] + offset[0], target[1] + offset[1], target[2] + offset[2]]} intensity={intensity} color={color} castShadow
        shadow-mapSize-width={2048} shadow-mapSize-height={2048} shadow-camera-left={-size} shadow-camera-right={size} shadow-camera-top={size} shadow-camera-bottom={-size}
        shadow-camera-near={1} shadow-camera-far={90} shadow-bias={-0.0004} shadow-normalBias={0.03} />
    </group>
  );
}

function World({ t }: { t: number }) {
  const m = machineAt(t), cuts = cutsAt(t), fl = flowsAt(t), A = anchors(t), cam = cameraAt(t);
  const table = t < 11.3, site = t >= 11.2;
  const events = useMemo(() => {
    const at = (tt: number) => anchors(tt).bucketTip;
    return { dig: [12.05, 39.0, 60.0, 68.2].map(tt => ({ tt, p: at(tt + 0.1) as V3 })), dump: [13.7, 40.75, 51.5, 65.45].map(tt => ({ tt, p: at(tt) as V3 })) };
  }, []);
  const grab = anchors(15.0).bucketTip, drop = anchors(19.1).rock;
  const trackPuffs = useMemo(() => {
    const out: { tb: number; p: V3 }[] = [];
    for (let tb = 53.7; tb < 58.0; tb += 0.11) { const mm = machineAt(tb); for (const s of [-1.1, 1.1]) out.push({ tb, p: [mm.x - 1.9, mm.y + 0.15, s] }); }
    return out;
  }, []);
  const stack = (tt: number): V3 => { const mm = machineAt(tt); return [mm.x - 1.25, mm.y + 3.0, 0.55]; };
  const puffs: number[] = []; for (let k = 21.1; k < 23.4; k += 0.18) puffs.push(k);
  for (let k = 11.5; k < 19.6; k += 0.55) puffs.push(k);
  for (let k = 23.4; k < 69.8; k += 0.7) puffs.push(k);
  return (
    <>
      {table ? <color attach="background" args={['#1a1410']} /> : <color attach="background" args={['#c9b28c']} />}
      {site && <fog attach="fog" args={['#d3bf9c', 60, 260]} />}
      <Env />
      <Rig t={t} />
      <hemisphereLight args={['#bcd4ee', '#6d5538', 0.55]} />
      {site && <Sun target={[m.x + 3, 0, -1]} offset={[16, 20, 12]} intensity={3.1} color="#ffe2b8" />}
      {table && <>
        <Sun target={[TABLE[0], 0, 0]} offset={[-6, 14, 12]} intensity={3.4} color="#ffd9aa" size={16} />
        <pointLight position={[TABLE[0] + 8, 6, 6]} intensity={90} color="#8fb8ff" distance={40} />
        <ambientLight intensity={0.25} />
      </>}
      {table && <SyringeScene t={t} />}
      {site && <>
        <Site t={t} camPos={cam.pos} />
        <Excavator m={m} cuts={cuts} fl={fl} t={t} />
        <RockMesh pos={A.rock} spin={0.4 + m.swing} s={1} />
        {t >= 16.4 && t < 19.3 && <TinySyringe t={t} pos={[A.boomCylMid[0] + 0.55, A.boomCylMid[1] + 0.3, A.boomCylMid[2] + 0.62]} />}
        {events.dig.map((e, i) => <Dust key={'d' + i} t={t} t0={e.tt} dur={1.4} pos={[e.p[0], groundH(e.p[0], e.p[2]) + 0.1, e.p[2]]} n={10} spread={1.3} size={0.4} seed={i + 1} />)}
        {events.dump.map((e, i) => <React.Fragment key={'u' + i}>
          <Falling t={t} t0={e.tt} from={e.p} ground={0.2} seed={i + 2} />
          <Dust t={t} t0={e.tt + 0.55} dur={1.6} pos={[e.p[0], 0.2, e.p[2]]} n={9} spread={1.5} size={0.5} seed={i + 9} />
        </React.Fragment>)}
        <Dust t={t} t0={15.0} dur={1.2} pos={[grab[0], 0.15, grab[2]]} n={8} spread={1.0} size={0.4} seed={21} />
        <Dust t={t} t0={19.1} dur={1.6} pos={[drop[0], 0.1, drop[2]]} n={10} spread={1.3} size={0.45} seed={22} />
        {trackPuffs.map((p, i) => <Dust key={'tp' + i} t={t} t0={p.tb} dur={1.3} pos={p.p} n={4} spread={0.9} rise={0.5} size={0.3} seed={i + 40} />)}
        {puffs.map((k, i) => <Dust key={'sm' + i} t={t} t0={k} dur={1.5} pos={stack(k)} n={3} spread={0.25} rise={0.9} size={k < 23.4 && k > 21 ? 0.3 : 0.14} seed={i + 90} smoke />)}
      </>}
    </>
  );
}

const Stem = ({ file, vol = 1 }: { file: string; vol?: number }) => <Audio src={staticFile(`audio/${file}`)} volume={vol} />;

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const cam = cameraAt(t);
  const fadeIn = clamp(frame / 6), fadeOut = clamp((2094 - 1 - frame) / 10);
  return (
    <AbsoluteFill style={{ backgroundColor: '#000' }}>
      <AbsoluteFill style={{ filter: cam.blur > 0.2 ? `blur(${cam.blur.toFixed(1)}px)` : undefined }}>
        <ThreeCanvas width={WIDTH} height={HEIGHT} shadows camera={{ fov: 34, near: 0.1, far: 1500, position: [0, 5, 10] }} gl={{ antialias: true, preserveDrawingBuffer: true }}>
          <World t={t} />
        </ThreeCanvas>
      </AbsoluteFill>
      {/* cinematic grade: warm vignette only (no text, no captions) */}
      <AbsoluteFill style={{ background: 'radial-gradient(ellipse at 50% 42%, rgba(0,0,0,0) 55%, rgba(8,5,2,0.45) 100%)', pointerEvents: 'none' }} />
      <AbsoluteFill style={{ background: 'linear-gradient(180deg, rgba(255,170,80,0.05), rgba(20,40,80,0.07))', mixBlendMode: 'soft-light', pointerEvents: 'none' }} />
      <AbsoluteFill style={{ backgroundColor: '#000', opacity: 1 - Math.min(fadeIn, fadeOut), pointerEvents: 'none' }} />
      {/* audio: voiceover is the master; every layer is a separate stem (ducking baked from the real voiceover envelope) */}
      <Audio src={staticFile('voiceover.mp3')} volume={1} />
      <Stem file="music.mp3" />
      <Stem file="sfx_mechanical.mp3" />
      <Stem file="sfx_camera.mp3" />
      <Stem file="sfx_funny.mp3" />
    </AbsoluteFill>
  );
};
