import data from './data/timeline.json';

export const FPS = data.fps;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const VOICE_SECONDS = data.voiceoverSeconds;
export const DURATION_FRAMES = Math.ceil(VOICE_SECONDS * FPS); // 69.79 s -> 2094 frames
export const sentences = data.sentences;

export type Keys = number[][];
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (t: number) => { const x = clamp(t); return x * x * (3 - 2 * x); };
export const smoother = (t: number) => { const x = clamp(t); return x * x * x * (x * (x * 6 - 15) + 10); };
export const ramp = (t: number, a: number, b: number) => smooth((t - a) / (b - a));
export const win = (t: number, a: number, b: number) => (t >= a && t < b ? 1 : 0);

/** Keyframe track: smoothstep between consecutive keys (zero velocity at keys, like a real valve spool settling). */
export function track(keys: Keys, t: number): number {
  if (t <= keys[0][0]) return keys[0][1];
  const last = keys[keys.length - 1];
  if (t >= last[0]) return last[1];
  let i = 0;
  while (i < keys.length - 1 && keys[i + 1][0] <= t) i++;
  const [t0, v0] = keys[i]; const [t1, v1] = keys[i + 1];
  return lerp(v0, v1, smooth((t - t0) / (t1 - t0)));
}

export interface Pose {
  boom: number; stick: number; bucket: number; swing: number;
  fill: number; pitch: number; travel: number; strain: number; rockAttach: number;
  engineRun: number;
}
const P = data.pose as Record<string, Keys>;

export function poseAt(t: number): Pose {
  const strain = track(P.strain, t);
  // hydraulic stall shake: small, high-frequency, only while the load exceeds what the arm can raise
  const shake = strain * (Math.sin(t * 61) * 0.35 + Math.sin(t * 37.3) * 0.25);
  return {
    boom: track(P.boom, t) + shake,
    stick: track(P.stick, t),
    bucket: track(P.bucket, t),
    swing: track(P.swing, t),
    fill: track(P.fill, t),
    pitch: track(P.pitch, t),
    travel: track(P.travel, t),
    strain,
    rockAttach: track(P.rockAttach, t),
    engineRun: track(data.cut.engineRun, t),
  };
}

export const sentenceAt = (t: number) => sentences.find(s => t >= s.a && t < s.b + 0.001);
export const frameToSec = (f: number) => f / FPS;
export const secToFrame = (s: number) => Math.round(s * FPS);
export const sfx = data.sfx;
export const musicBoost = data.musicBoost;

/** Deterministic pseudo random (mulberry32) so every frame renders identically on any machine. */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
