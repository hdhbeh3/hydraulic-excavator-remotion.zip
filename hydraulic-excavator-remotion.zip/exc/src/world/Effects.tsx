import React from 'react';
import * as THREE from 'three';
import { M, sph } from './common';
import { rng, clamp } from '../timeline';
import { V3 } from '../world';

const mk = (o: number, c = '#b89c78') => new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: o, depthWrite: false });
const DUST = [mk(0.42), mk(0.3), mk(0.18), mk(0.07)];
const SMOKE = [mk(0.42, '#262626'), mk(0.3, '#303030'), mk(0.18, '#3a3a3a'), mk(0.07, '#404040')];

export function Dust({ t, t0, dur = 1.6, pos, n = 9, spread = 1.1, rise = 0.9, size = 0.35, seed = 1, smoke = false, vy = 0 }:
  { t: number; t0: number; dur?: number; pos: V3; n?: number; spread?: number; rise?: number; size?: number; seed?: number; smoke?: boolean; vy?: number }) {
  const age = (t - t0) / dur;
  if (age < 0 || age > 1) return null;
  const r = rng(seed * 977 + Math.round(t0 * 100));
  const mats = smoke ? SMOKE : DUST;
  const lvl = Math.min(3, Math.floor(age * 4));
  return <group>{Array.from({ length: n }, (_, i) => {
    const a = r() * Math.PI * 2, sp = 0.3 + r() * 0.7, lift = 0.4 + r() * 0.8;
    const p: V3 = [pos[0] + Math.cos(a) * spread * sp * Math.sqrt(age), pos[1] + rise * lift * age + vy * age, pos[2] + Math.sin(a) * spread * sp * Math.sqrt(age)];
    const s = size * (0.45 + age * 1.5) * (0.7 + r() * 0.6);
    return <mesh key={i} geometry={sph(1, 8, 6)} material={mats[lvl]} position={p} scale={[s, s * 0.8, s]} />;
  })}</group>;
}
/** Soil chunks falling out of the bucket. */
export function Falling({ t, t0, from, ground, n = 26, seed = 3 }: { t: number; t0: number; from: V3; ground: number; n?: number; seed?: number }) {
  const age = t - t0; if (age < 0 || age > 1.8) return null;
  const r = rng(seed * 313 + Math.round(t0 * 50));
  return <group>{Array.from({ length: n }, (_, i) => {
    const vx = (r() - 0.5) * 1.6, vz = (r() - 0.5) * 1.6, y0 = from[1] + (r() - 0.5) * 0.3, s = 0.05 + r() * 0.1;
    const y = Math.max(ground + 0.1 + r() * 0.2, y0 - 4.9 * age * age);
    const landed = y <= ground + 0.4 && age > 0.3;
    return <mesh key={i} geometry={sph(1, 6, 5)} material={i % 3 ? M.soil : M.soilDark} position={[from[0] + vx * Math.min(age, 0.6), y, from[2] + vz * Math.min(age, 0.6)]} scale={[s, s, s].map(v => v * (landed ? clamp(1.8 - age, 0, 1) : 1)) as V3} />;
  })}</group>;
}
