import React, { useMemo } from 'react';
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import type { V3 } from '../world';

// ---------- shared materials (module-level so they are created once) ----------
const std = (color: string, metalness: number, roughness: number, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
  new THREE.MeshStandardMaterial({ color, metalness, roughness, envMapIntensity: 0.9, ...extra });

export const M = {
  yellow: std('#f0b000', 0.35, 0.36),
  yellowDark: std('#c98f00', 0.35, 0.45),
  steel: std('#2b2d31', 0.65, 0.48),
  steelLight: std('#6b7078', 0.8, 0.35),
  cast: std('#34363a', 0.5, 0.62),
  rubber: std('#0f1011', 0.1, 0.92),
  chrome: std('#dfe3e8', 1.0, 0.1, { envMapIntensity: 1.4 }),
  track: std('#202225', 0.7, 0.55),
  grouser: std('#3a3c40', 0.7, 0.5),
  glass: std('#a8d8ea', 0.1, 0.05, { transparent: true, opacity: 0.22, depthWrite: false, side: THREE.DoubleSide }),
  ghost: std('#b9c3cc', 0.2, 0.2, { transparent: true, opacity: 0.12, depthWrite: false, side: THREE.DoubleSide }),
  soil: std('#7a5a3a', 0, 1),
  soilDark: std('#4d3822', 0, 1),
  rock: std('#8a8680', 0.05, 0.95, { flatShading: true }),
  amber: std('#ffb21f', 0.0, 0.25, { emissive: '#ff8a00', emissiveIntensity: 0.55, transparent: true, opacity: 0.92 }),
  amberSoft: std('#ffb21f', 0.0, 0.3, { emissive: '#ff8a00', emissiveIntensity: 0.3, transparent: true, opacity: 0.55, depthWrite: false }),
  cyan: new THREE.MeshBasicMaterial({ color: '#4fe0ff', transparent: true, opacity: 0.95, toneMapped: false }),
  cyanSoft: new THREE.MeshBasicMaterial({ color: '#4fe0ff', transparent: true, opacity: 0.38, depthWrite: false, toneMapped: false }),
  smoke: new THREE.MeshBasicMaterial({ color: '#2a2a2a', transparent: true, opacity: 0.4, depthWrite: false }),
  blueOil: std('#2f7bff', 0.0, 0.2, { emissive: '#1450d0', emissiveIntensity: 0.55, transparent: true, opacity: 0.85 }),
  orangeLiquid: std('#ff7a18', 0.0, 0.2, { emissive: '#d84a00', emissiveIntensity: 0.4, transparent: true, opacity: 0.88 }),
  plastic: std('#d8e6ee', 0.0, 0.08, { transparent: true, opacity: 0.28, depthWrite: false, side: THREE.DoubleSide }),
  white: std('#e8e8e8', 0.1, 0.5),
  red: std('#b3201b', 0.45, 0.3),
  hazard: std('#e7b100', 0.2, 0.6),
  dust: new THREE.MeshBasicMaterial({ color: '#b79a76', transparent: true, opacity: 0.35, depthWrite: false }),
  glove: std('#d9591a', 0.0, 0.8),
  sleeve: std('#1d2a3a', 0.0, 0.9),
  concrete: std('#8d8f91', 0.0, 0.95),
  glow: new THREE.MeshBasicMaterial({ color: '#ffd27a', transparent: true, opacity: 0.35, depthWrite: false }),
};

// ---------- cached geometry factories ----------
const cache = new Map<string, THREE.BufferGeometry>();
const memo = <T extends THREE.BufferGeometry>(k: string, f: () => T): T => { let g = cache.get(k); if (!g) { g = f(); cache.set(k, g); } return g as T; };
export const rbox = (w: number, h: number, d: number, r = 0.05) => memo(`rb${w}_${h}_${d}_${r}`, () => new RoundedBoxGeometry(w, h, d, 2, Math.min(r, w / 2 - 0.001, h / 2 - 0.001, d / 2 - 0.001)));
export const box = (w: number, h: number, d: number) => memo(`bx${w}_${h}_${d}`, () => new THREE.BoxGeometry(w, h, d));
export const cyl = (rt: number, rb: number, h: number, seg = 20, open = false) => memo(`cy${rt}_${rb}_${h}_${seg}_${open}`, () => new THREE.CylinderGeometry(rt, rb, h, seg, 1, open));
export const sph = (r: number, ws = 14, hs = 10) => memo(`sp${r}_${ws}_${hs}`, () => new THREE.SphereGeometry(r, ws, hs));
export const UNIT_CYL = new THREE.CylinderGeometry(1, 1, 1, 12, 1);
const UP = new THREE.Vector3(0, 1, 0);

/** Beam: extruded 2D polygon in the XY (side) plane, thickness along z, centred on z. */
export function beamGeometry(pts: [number, number][], depth: number, bevel = 0.03): THREE.BufferGeometry {
  const key = 'beam' + JSON.stringify(pts) + depth + bevel;
  return memo(key, () => {
    const sh = new THREE.Shape(); sh.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) sh.lineTo(pts[i][0], pts[i][1]);
    sh.closePath();
    const g = new THREE.ExtrudeGeometry(sh, { depth: depth - bevel * 2, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 1, steps: 1 });
    g.translate(0, 0, -(depth - bevel * 2) / 2);
    return g;
  });
}

/** Straight cylinder segment from a to b (world/local of parent). */
export function Seg({ a, b, r, mat, cast = true }: { a: V3; b: V3; r: number; mat: THREE.Material; cast?: boolean }) {
  const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
  const l = Math.hypot(dx, dy, dz);
  if (l < 1e-5) return null;
  const q = new THREE.Quaternion().setFromUnitVectors(UP, new THREE.Vector3(dx / l, dy / l, dz / l));
  return <mesh geometry={UNIT_CYL} material={mat} position={[(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]} quaternion={q} scale={[r, l, r]} castShadow={cast} />;
}

/** Smooth polyline through control points (Catmull-Rom), returned as dense points. */
export function smoothPath(ctrl: V3[], n = 14): V3[] {
  if (ctrl.length < 3) return ctrl;
  const c = new THREE.CatmullRomCurve3(ctrl.map(p => new THREE.Vector3(...p)), false, 'catmullrom', 0.5);
  return c.getPoints(n).map(v => [v.x, v.y, v.z] as V3);
}
export function pathLength(p: V3[]) { let l = 0; for (let i = 1; i < p.length; i++) l += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1], p[i][2] - p[i - 1][2]); return l; }
export function pointAt(p: V3[], u: number): V3 {
  const total = pathLength(p); let d = ((u % 1) + 1) % 1 * total;
  for (let i = 1; i < p.length; i++) {
    const l = Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1], p[i][2] - p[i - 1][2]);
    if (d <= l || i === p.length - 1) { const k = l ? d / l : 0; return [p[i - 1][0] + (p[i][0] - p[i - 1][0]) * k, p[i - 1][1] + (p[i][1] - p[i - 1][1]) * k, p[i - 1][2] + (p[i][2] - p[i - 1][2]) * k]; }
    d -= l;
  }
  return p[p.length - 1];
}

/**
 * Flexible hose / rigid pipe with optional see-through cutaway and animated oil particles.
 * cut: 0 = opaque jacket, 1 = glass jacket showing amber oil core + flow particles.
 * flow: signed intensity, + flows from first to last point, - the opposite. pressure -> cyan particles.
 */
export function Hose({ pts, r = 0.05, cut = 0, flow = 0, pressure = false, t, rigid = false, speed = 1.1 }:
  { pts: V3[]; r?: number; cut?: number; flow?: number; pressure?: boolean; t: number; rigid?: boolean; speed?: number }) {
  const path = useMemo(() => (rigid ? pts : smoothPath(pts, 12)), [JSON.stringify(pts.map(p => p.map(v => Math.round(v * 500))))]); // eslint-disable-line
  const jacket = rigid ? M.steel : M.rubber;
  const jm = cut > 0.02 ? M.ghost : jacket;
  const len = pathLength(path);
  const nP = Math.max(3, Math.round(len / 0.38));
  const f = Math.abs(flow);
  const parts: JSX.Element[] = [];
  if (cut > 0.02) for (let i = 1; i < path.length; i++) parts.push(<Seg key={'o' + i} a={path[i - 1]} b={path[i]} r={r * 0.78} mat={M.amberSoft} cast={false} />);
  const ps: JSX.Element[] = [];
  if (cut > 0.02 && f > 0.02) for (let i = 0; i < nP; i++) {
    const u = (i / nP + Math.sign(flow) * t * speed / Math.max(len, 0.5)) ;
    const p = pointAt(path, u);
    ps.push(<mesh key={'p' + i} geometry={sph(r * (0.55 + 0.35 * f), 8, 6)} material={pressure ? M.cyan : M.amber} position={p} />);
  }
  return (
    <group>
      {path.slice(1).map((p, i) => <Seg key={'j' + i} a={path[i]} b={p} r={r} mat={jm} cast={cut < 0.02} />)}
      {parts}{ps}
    </group>
  );
}
export const deg = (d: number) => (d * Math.PI) / 180;
