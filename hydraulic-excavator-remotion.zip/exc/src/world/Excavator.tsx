import React from 'react';
import * as THREE from 'three';
import { M, box, rbox, cyl, sph, beamGeometry, Seg, Hose, UNIT_CYL, deg } from './common';
import { PowerPack, Cab, Undercarriage } from './Parts';
import { G, SPEC, solveArm, V2, CylSpec } from '../kinematics';
import { Machine, V3, L } from '../world';
import { Cuts, Flows } from '../cutaways';
import { smooth, ramp } from '../timeline';

const BOOM = beamGeometry([[0, 0.42], [0.9, 0.62], [1.8, 0.95], [2.6, 1.0], [3.3, 0.82], [4.1, 0.55], [4.75, 0.34], [4.75, -0.28], [4.1, -0.3], [3.3, -0.3], [2.6, -0.22], [1.7, -0.12], [0.9, -0.12], [0, -0.2]], 0.55);
const STICK = beamGeometry([[-0.45, 0.45], [0.2, 0.62], [1.0, 0.4], [2.0, 0.25], [2.4, 0.22], [2.4, -0.22], [2.0, -0.2], [1.0, -0.28], [0.2, -0.4], [-0.45, -0.05]], 0.4);
const BKT_SHELL = beamGeometry([[-0.3, 0.18], [-0.2, 0.42], [0.2, 0.62], [0.7, 0.62], [1.1, 0.38], [1.32, 0.02], [1.3, -0.06], [1.0, 0.26], [0.65, 0.46], [0.2, 0.46], [-0.05, 0.3], [-0.18, 0.14]], 1.25, 0.015);
const BKT_SIDE = beamGeometry([[-0.3, 0.18], [-0.2, 0.42], [0.2, 0.62], [0.7, 0.62], [1.1, 0.38], [1.32, 0.02], [1.3, -0.06], [-0.2, 0.02]], 0.07, 0.01);
const CONE = new THREE.ConeGeometry(1, 1, 14);
const rock = (() => { const g = new THREE.DodecahedronGeometry(1, 1); const p = g.attributes.position; for (let i = 0; i < p.count; i++) { const k = 0.82 + 0.3 * Math.abs(Math.sin(p.getX(i) * 7.1 + p.getY(i) * 3.3 + p.getZ(i) * 5.7)); p.setXYZ(i, p.getX(i) * k, p.getY(i) * k, p.getZ(i) * k); } g.computeVertexNormals(); return g; })();
export const RockMesh = ({ pos, spin = 0, s = 1 }: { pos: V3; spin?: number; s?: number }) => (
  <mesh geometry={rock} material={M.rock} position={pos} rotation={[0.3, spin, 0.2]} scale={[0.72 * s, 0.56 * s, 0.64 * s]} castShadow receiveShadow />
);

export function HydCyl({ a, b, z, spec, cut, flow, r = 0.1 }: { a: V2; b: V2; z: number; spec: CylSpec; cut: number; flow: number; r?: number }) {
  const dx = b[0] - a[0], dy = b[1] - a[1]; const Lc = Math.hypot(dx, dy); const ang = Math.atan2(dy, dx);
  const pos = Math.max(0.12, Lc - spec.rod);
  const isCut = cut > 0.02;
  const X = Math.PI / 2;
  return (
    <group position={[a[0], a[1], z]} rotation={[0, 0, ang]}>
      <mesh geometry={cyl(r, r, spec.barrel, 24, true)} material={isCut ? M.ghost : M.yellowDark} position={[spec.barrel / 2, 0, 0]} rotation={[0, 0, X]} castShadow={!isCut} />
      {!isCut && <mesh geometry={cyl(r, r, 0.001, 24)} material={M.yellowDark} position={[spec.barrel, 0, 0]} rotation={[0, 0, X]} />}
      <mesh geometry={cyl(r * 1.12, r * 1.12, 0.16, 20)} material={M.steel} position={[0.08, 0, 0]} rotation={[0, 0, X]} castShadow />
      <mesh geometry={cyl(r * 1.1, r * 1.1, 0.14, 20)} material={M.steel} position={[spec.barrel - 0.07, 0, 0]} rotation={[0, 0, X]} castShadow />
      <mesh geometry={UNIT_CYL} material={M.chrome} position={[(pos + Lc) / 2, 0, 0]} rotation={[0, 0, X]} scale={[r * 0.5, Lc - pos, r * 0.5]} castShadow />
      <mesh geometry={cyl(0.1, 0.1, 0.46, 16)} material={M.steel} position={[0, 0, 0]} rotation={[X, 0, 0]} castShadow />
      <mesh geometry={cyl(0.1, 0.1, 0.46, 16)} material={M.steel} position={[Lc, 0, 0]} rotation={[X, 0, 0]} castShadow />
      {isCut && <>
        <mesh geometry={cyl(r * 0.95, r * 0.95, 0.07, 24)} material={M.steelLight} position={[pos, 0, 0]} rotation={[0, 0, X]} />
        <mesh geometry={UNIT_CYL} material={M.amber} position={[(0.16 + pos) / 2, 0, 0]} rotation={[0, 0, X]} scale={[r * 0.88, Math.max(pos - 0.2, 0.01), r * 0.88]} />
        <mesh geometry={UNIT_CYL} material={M.amberSoft} position={[(pos + 0.04 + spec.barrel - 0.14) / 2, 0, 0]} rotation={[0, 0, X]} scale={[r * 0.88, Math.max(spec.barrel - 0.18 - pos, 0.01), r * 0.88]} />
        {flow > 0.05 && <mesh geometry={UNIT_CYL} material={M.cyanSoft} position={[(0.16 + pos) / 2, 0, 0]} rotation={[0, 0, X]} scale={[r * 0.93, Math.max(pos - 0.2, 0.01), r * 0.93]} />}
        {flow < -0.05 && <mesh geometry={UNIT_CYL} material={M.cyanSoft} position={[(pos + 0.04 + spec.barrel - 0.14) / 2, 0, 0]} rotation={[0, 0, X]} scale={[r * 0.93, Math.max(spec.barrel - 0.18 - pos, 0.01), r * 0.93]} />}
      </>}
    </group>
  );
}
const ports = (a: V2, b: V2, z: number, spec: CylSpec, r = 0.1): { cap: V3; rod: V3 } => {
  const dx = b[0] - a[0], dy = b[1] - a[1]; const l = Math.hypot(dx, dy); const ux = dx / l, uy = dy / l; const px = -uy, py = ux;
  return { cap: [a[0] + ux * 0.12 + px * (r + 0.03), a[1] + uy * 0.12 + py * (r + 0.03), z], rod: [a[0] + ux * (spec.barrel - 0.12) + px * (r + 0.03), a[1] + uy * (spec.barrel - 0.12) + py * (r + 0.03), z] };
};

export function Arm({ m, cuts, fl, t }: { m: Machine; cuts: Cuts; fl: Flows; t: number }) {
  const a = m.arm; const { boom, stick, bucket } = { boom: m.pose.boom, stick: m.pose.stick, bucket: m.pose.bucket };
  const bl = (x: number, y: number, z: number): V3 => [G.P0[0] + x * Math.cos(a.a1) - y * Math.sin(a.a1), G.P0[1] + x * Math.sin(a.a1) + y * Math.cos(a.a1), z];
  const sl = (x: number, y: number, z: number): V3 => [a.E[0] + x * Math.cos(a.a2) - y * Math.sin(a.a2), a.E[1] + x * Math.sin(a.a2) + y * Math.cos(a.a2), z];
  const cut = cuts.cyl, hc = cuts.hose;
  const pB = ports(a.boomCyl.a, a.boomCyl.b, 0.4, SPEC.boom), pBn = ports(a.boomCyl.a, a.boomCyl.b, -0.4, SPEC.boom);
  const pS = ports(a.stickCyl.a, a.stickCyl.b, 0, SPEC.stick), pK = ports(a.bktCyl.a, a.bktCyl.b, 0, SPEC.bucket);
  const v0: V3 = [L.valve[0] + 0.1, L.valve[1] - 0.12, L.valve[2]];
  const hose = (k: string, pts: V3[], f: number, r = 0.04) => <Hose key={k} pts={pts} r={r} cut={hc} flow={f} pressure={f > 0} t={t} />;
  const zs = [0.4, -0.4];
  return (
    <group>
      {/* boom */}
      <group position={[G.P0[0], G.P0[1], 0]} rotation={[0, 0, a.a1]}>
        <mesh geometry={BOOM} material={M.yellow} castShadow receiveShadow />
        <mesh geometry={box(0.5, 0.3, 0.64)} material={M.steel} position={[0.1, 0.05, 0]} castShadow />
        <mesh geometry={box(0.24, 0.2, 0.66)} material={M.steel} position={[1.75, -0.2, 0]} castShadow />
        <mesh geometry={box(0.3, 0.22, 0.4)} material={M.steel} position={[3.1, 0.88, 0]} castShadow />
        {/* stick */}
        <group position={[G.Lb, 0, 0]} rotation={[0, 0, a.a2 - a.a1]}>
          <mesh geometry={STICK} material={M.yellow} castShadow receiveShadow />
          <mesh geometry={cyl(0.2, 0.2, 0.46, 20)} material={M.steel} rotation={[Math.PI / 2, 0, 0]} castShadow />
          <mesh geometry={box(0.3, 0.26, 0.36)} material={M.steel} position={[-0.25, 0.68, 0]} castShadow />
          <mesh geometry={box(0.28, 0.2, 0.36)} material={M.steel} position={[0.5, 0.5, 0]} castShadow />
          {/* bucket */}
          <group position={[G.Ls, 0, 0]} rotation={[0, 0, a.a3 - a.a2]}>
            <mesh geometry={cyl(0.17, 0.17, 0.5, 18)} material={M.steel} rotation={[Math.PI / 2, 0, 0]} castShadow />
            <mesh geometry={BKT_SHELL} material={M.steel} castShadow receiveShadow />
            <mesh geometry={BKT_SIDE} material={M.steel} position={[0, 0, 0.6]} castShadow />
            <mesh geometry={BKT_SIDE} material={M.steel} position={[0, 0, -0.6]} castShadow />
            <mesh geometry={box(0.16, 0.12, 1.2)} material={M.steelLight} position={[0.1, 0.5, 0]} castShadow />
            {[-0.5, -0.25, 0, 0.25, 0.5].map(z => <mesh key={z} geometry={box(0.2, 0.07, 0.12)} material={M.steelLight} position={[1.32, -0.02, z]} rotation={[0, 0, -0.35]} castShadow />)}
            {m.pose.fill > 0.02 && <mesh geometry={sph(1, 16, 10)} material={M.soil} position={[0.62, 0.12 - 0.05 * m.pose.fill, 0]} scale={[0.62, 0.2 + 0.22 * m.pose.fill, 0.56]} castShadow />}
            {m.pose.fill > 1.05 && <mesh geometry={sph(1, 12, 8)} material={M.soilDark} position={[0.5, -0.1, 0.05]} scale={[0.6, 0.32 * m.pose.fill, 0.5]} castShadow />}
          </group>
        </group>
      </group>
      {/* pins */}
      {[a.P0, a.E, a.K].map((p, i) => <mesh key={i} geometry={cyl(0.12, 0.12, 0.7, 16)} material={M.steelLight} position={[p[0], p[1], 0]} rotation={[Math.PI / 2, 0, 0]} castShadow />)}
      {/* cylinders (lengths come straight from the pin geometry => physically consistent strokes) */}
      {zs.map((z, i) => <HydCyl key={'b' + i} a={a.boomCyl.a} b={a.boomCyl.b} z={z} spec={SPEC.boom} cut={cut} flow={fl.boom} r={0.105} />)}
      <HydCyl a={a.stickCyl.a} b={a.stickCyl.b} z={0.0} spec={SPEC.stick} cut={cut} flow={fl.stick} r={0.1} />
      <HydCyl a={a.bktCyl.a} b={a.bktCyl.b} z={0.0} spec={SPEC.bucket} cut={cut} flow={fl.bucket} r={0.085} />
      {/* bucket linkage (dog-bones) */}
      {[0.22, -0.22].map(z => <React.Fragment key={z}><Seg a={[a.S2[0], a.S2[1], z]} b={[a.J[0], a.J[1], z]} r={0.04} mat={M.steelLight} /><Seg a={[a.J[0], a.J[1], z]} b={[a.Lk[0], a.Lk[1], z]} r={0.04} mat={M.steelLight} /></React.Fragment>)}
      <mesh geometry={cyl(0.07, 0.07, 0.56, 12)} material={M.steelLight} position={[a.J[0], a.J[1], 0]} rotation={[Math.PI / 2, 0, 0]} />
      {/* hoses: valve -> cylinder ports (cap line = flow toward the cylinder while extending) */}
      {zs.map((z, i) => { const p = i === 0 ? pB : pBn; return <React.Fragment key={'bh' + i}>
        {hose('bc' + i, [[v0[0], v0[1], z * 0.5], [1.0, 1.35, z * 0.9], [1.45, 1.1, z * 1.0], p.cap], fl.boom)}
        {hose('br' + i, [[v0[0] + 0.1, v0[1] + 0.1, z * 0.4], [1.3, 1.6, z * 0.95], [p.rod[0] - 0.2, p.rod[1] + 0.3, z], p.rod], -fl.boom)}
      </React.Fragment>; })}
      {hose('sc', [v0, bl(0.4, 0.75, 0.22), bl(1.9, 1.25, 0.24), bl(3.0, 1.2, 0.18), pS.cap], fl.stick)}
      {hose('sr', [[v0[0] + 0.05, v0[1], 0], bl(0.4, 0.7, -0.22), bl(1.9, 1.2, -0.24), bl(3.4, 1.05, -0.18), pS.rod], -fl.stick)}
      {hose('kc', [v0, bl(0.4, 0.8, 0.26), bl(2.6, 1.28, 0.28), bl(4.2, 0.78, 0.2), sl(-0.1, 0.8, 0.22), sl(0.3, 0.62, 0.15), pK.cap], fl.bucket, 0.035)}
      {hose('kr', [[v0[0] + 0.05, v0[1], 0], bl(0.4, 0.74, -0.26), bl(2.6, 1.22, -0.28), bl(4.2, 0.72, -0.2), sl(-0.1, 0.74, -0.22), sl(0.5, 0.6, -0.15), pK.rod], -fl.bucket, 0.035)}
    </group>
  );
}

export function Excavator({ m, cuts, fl, t }: { m: Machine; cuts: Cuts; fl: Flows; t: number }) {
  const load = deg(m.pose.pitch); const terrain = m.pitch + load;
  const cogX = 0.1 + 0.5 * m.pose.fill + 0.04 * m.arm.tip[0];
  const showBal = cuts.balance > 0.01;
  const late = t > 48;
  return (
    <group position={[m.x, m.y, 0]} rotation={[0, 0, terrain]}>
      <group position={[1.9, 0, 0]} rotation={[0, 0, -load]}>
        <group position={[-1.9, 0, 0]}>
          <Undercarriage m={m} cuts={cuts} fl={fl} t={t} />
          <group position={[0, 0, 0]} rotation={[0, m.swing, 0]}>
            <mesh geometry={cyl(0.9, 0.9, 0.22, 36)} material={M.steel} position={[0, 1.02, 0]} castShadow />
            <mesh geometry={rbox(4.0, 0.3, 2.45, 0.05)} material={M.cast} position={[-0.4, 1.15, 0]} castShadow receiveShadow />
            <mesh geometry={rbox(3.9, 0.12, 0.08, 0.02)} material={M.yellow} position={[-0.4, 1.02, 1.2]} />
            <mesh geometry={rbox(3.9, 0.12, 0.08, 0.02)} material={M.yellow} position={[-0.4, 1.02, -1.2]} />
            {/* engine cover */}
            <mesh geometry={rbox(1.5, 1.05, 2.0, 0.12)} material={cuts.cover < 0.5 ? M.ghost : M.yellow} position={[-0.9, 1.83, 0]} castShadow receiveShadow />
            {/* grille on the rear of the cover */}
            {[0, 1, 2, 3, 4].map(i => <mesh key={i} geometry={box(0.03, 0.04, 1.5)} material={M.steel} position={[-1.66, 1.55 + i * 0.12, 0]} />)}
            {/* tank side cover */}
            <mesh geometry={rbox(1.05, 0.85, 0.55, 0.06)} material={cuts.cover < 0.5 ? M.ghost : M.yellow} position={[L.tank[0], L.tank[1], L.tank[2]]} castShadow />
            {/* counterweight */}
            <mesh geometry={rbox(0.85, 1.1, 2.4, 0.1)} material={M.cast} position={[-2.0, 1.85, 0]} castShadow receiveShadow />
            <mesh geometry={box(0.88, 0.1, 2.0)} material={M.hazard} position={[-2.0, 2.45, 0]} />
            {[-0.8, 0, 0.8].map(z => <mesh key={z} geometry={box(0.05, 0.9, 0.18)} material={M.hazard} position={[-2.44, 1.85, z]} />)}
            {showBal && <mesh geometry={rbox(0.95, 1.2, 2.5, 0.1)} material={M.glow} position={[-2.0, 1.85, 0]} />}
            <PowerPack cuts={cuts} fl={fl} t={t} />
            <Cab cuts={cuts} fl={fl} t={t} />
            <Arm m={m} cuts={cuts} fl={fl} t={t} />
          </group>
          {showBal && <Balance cogX={cogX} late={late} k={cuts.balance} tipX={m.arm.tip[0]} />}
        </group>
      </group>
    </group>
  );
}

/** Teaching overlay: centre of gravity, tipping edge and the see-saw balance — subtle glow, no text. */
function Balance({ cogX, late, k, tipX }: { cogX: number; late: boolean; k: number; tipX: number }) {
  const arrow = (x: number, len: number, r: number, key: string) => <group key={key} position={[x, 4.6, 0]}>
    <Seg a={[0, 0, 0]} b={[0, -len, 0]} r={r} mat={M.amber} cast={false} />
    <mesh geometry={CONE} material={M.amber} position={[0, -len - r * 2.2, 0]} rotation={[Math.PI, 0, 0]} scale={[r * 2.6, r * 5, r * 2.6]} />
  </group>;
  if (!late) return <group scale={[k, k, k]}>
    <mesh geometry={sph(0.16, 16, 12)} material={M.cyan} position={[cogX, 1.8, 0]} />
    <Seg a={[cogX, 1.8, 0]} b={[cogX, 0.0, 0]} r={0.02} mat={M.cyan} cast={false} />
    <Seg a={[1.9, 0.0, 0]} b={[1.9, 1.5, 0]} r={0.03} mat={M.amber} cast={false} />
    <mesh geometry={sph(0.1, 10, 8)} material={M.amber} position={[1.9, 0.02, 0]} />
  </group>;
  return <group scale={[1, k, 1]} position={[0, (1 - k) * 4, 0]}>
    <mesh geometry={beamGeometry([[-0.55, 0], [0.55, 0], [0, 0.8]], 0.5, 0.02)} material={M.glow} position={[0.3, 4.6 - 0.9, 0]} />
    <mesh geometry={box(9.2, 0.06, 0.3)} material={M.glow} position={[1.6, 4.62, 0]} />
    {arrow(-2.0, 1.3, 0.1, 'rear')}
    {arrow(tipX + 0.6, 0.8, 0.07, 'front')}
    <mesh geometry={sph(0.16, 16, 12)} material={M.cyan} position={[0.3, 4.62, 0]} />
  </group>;
}
export { SPEC, ramp, smooth, solveArm };
