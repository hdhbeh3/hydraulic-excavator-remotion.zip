import React, { useMemo } from 'react';
import * as THREE from 'three';
import { M, box, rbox, cyl, sph } from './common';
import { groundH, PILE_A, PILE_B, PIT_A, PIT_B, MACH_X0 } from '../world';
import { rng, ramp, smooth } from '../timeline';

const SIZE = 150, N = 150;
function buildTerrain(): THREE.BufferGeometry {
  const pos = new Float32Array((N + 1) * (N + 1) * 3), col = new Float32Array((N + 1) * (N + 1) * 3);
  const idx: number[] = [];
  const base = new THREE.Color('#9a7d58'), dark = new THREE.Color('#5a4128'), dry = new THREE.Color('#b59a72'), c = new THREE.Color();
  for (let j = 0; j <= N; j++) for (let i = 0; i <= N; i++) {
    const x = (i / N - 0.5) * SIZE, z = (j / N - 0.5) * SIZE, k = j * (N + 1) + i;
    pos[k * 3] = x; pos[k * 3 + 1] = groundH(x, z); pos[k * 3 + 2] = z;
    const n = 0.5 + 0.5 * Math.sin(x * 0.9) * Math.sin(z * 1.1 + 2) * Math.sin(x * 0.17 + z * 0.23);
    c.copy(base).lerp(dry, n * 0.6);
    for (const p of [PIT_A, PIT_B]) c.lerp(dark, 0.75 * (1 - Math.min(1, Math.hypot(x - p[0], z - p[2]) / 3.6)) ** 1.3);
    const track = Math.exp(-((z * z) / 3.5)) * ramp(x, -2, 3) * 0.35; c.lerp(dark, track);
    col[k * 3] = c.r; col[k * 3 + 1] = c.g; col[k * 3 + 2] = c.b;
  }
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const a = j * (N + 1) + i, b = a + 1, d = a + N + 1, e = d + 1; idx.push(a, d, b, b, d, e); }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.setIndex(idx); g.computeVertexNormals();
  return g;
}

function scatter(geo: THREE.BufferGeometry, mat: THREE.Material, count: number, seed: number, radius: number, sMin: number, sMax: number, avoid: (x: number, z: number) => boolean, flat = 1): THREE.InstancedMesh {
  const r = rng(seed); const im = new THREE.InstancedMesh(geo, mat, count); const o = new THREE.Object3D(); const col = new THREE.Color();
  let k = 0, guard = 0;
  while (k < count && guard++ < count * 20) {
    const a = r() * Math.PI * 2, d = Math.sqrt(r()) * radius, x = Math.cos(a) * d + 4, z = Math.sin(a) * d;
    if (avoid(x, z)) continue;
    const s = sMin + r() * (sMax - sMin);
    o.position.set(x, groundH(x, z) + s * 0.25, z); o.rotation.set(r() * 3, r() * 3, r() * 3); o.scale.set(s * (0.8 + r() * 0.5), s * flat, s * (0.8 + r() * 0.5)); o.updateMatrix(); im.setMatrixAt(k, o.matrix);
    const g = 0.45 + r() * 0.35; col.setRGB(g * (0.95 + r() * 0.1), g * 0.92, g * 0.85); im.setColorAt(k, col); k++;
  }
  im.count = k; im.castShadow = true; im.receiveShadow = true; im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
  return im;
}
const nearWork = (x: number, z: number) => x > MACH_X0 - 3.5 && x < MACH_X0 + 16 && Math.abs(z) < 3 || Math.hypot(x - PILE_A[0], z - PILE_A[2]) < 3.2 || Math.hypot(x - PILE_B[0], z - PILE_B[2]) < 3.2;

const CONE = new THREE.ConeGeometry(0.2, 0.7, 14);
let SKY: THREE.CanvasTexture | null = null;
function skyTex() {
  if (SKY) return SKY;
  const c = document.createElement('canvas'); c.width = 8; c.height = 512; const g = c.getContext('2d')!;
  const gr = g.createLinearGradient(0, 0, 0, 512);
  gr.addColorStop(0, '#3f78b8'); gr.addColorStop(0.45, '#8fb6d8'); gr.addColorStop(0.5, '#e9d3a8'); gr.addColorStop(0.56, '#d9c19a'); gr.addColorStop(1, '#b49a76');
  g.fillStyle = gr; g.fillRect(0, 0, 8, 512);
  SKY = new THREE.CanvasTexture(c); SKY.colorSpace = THREE.SRGBColorSpace; return SKY;
}

export function Site({ t, camPos }: { t: number; camPos: [number, number, number] }) {
  const terrain = useMemo(buildTerrain, []);
  const gravel = useMemo(() => scatter(new THREE.IcosahedronGeometry(1, 0), M.rock, 520, 11, 22, 0.05, 0.16, nearWork, 0.7), []);
  const rocks = useMemo(() => scatter(new THREE.DodecahedronGeometry(1, 0), M.rock, 46, 21, 48, 0.35, 1.2, (x, z) => nearWork(x, z) || Math.hypot(x, z) < 8, 0.7), []);
  const clods = useMemo(() => scatter(new THREE.IcosahedronGeometry(1, 0), M.soilDark, 260, 31, 14, 0.07, 0.2, (x, z) => x > MACH_X0 - 3 && x < MACH_X0 + 3 && Math.abs(z) < 2.2, 0.8), []);
  const hA = 0.3 + 0.38 * ramp(t, 13.65, 14.05) + 0.38 * ramp(t, 40.7, 41.1) + 0.55 * ramp(t, 51.45, 51.95);
  const hB = 0.3 + 0.55 * ramp(t, 65.4, 65.95);
  const showSky = t >= 11.2;
  const mounds = useMemo(() => [[-30, -38, 9, 3.4], [22, -44, 13, 4.5], [48, -20, 10, 3.2], [-48, 10, 12, 4], [-20, 46, 14, 4.2], [30, 44, 11, 3.6]], []);
  const cones = [[-6, 7], [-3, 7.4], [10, 7], [13, 6.6]];
  return (
    <group>
      <mesh geometry={terrain} receiveShadow><meshStandardMaterial vertexColors roughness={1} metalness={0} /></mesh>
      <primitive object={gravel} /><primitive object={rocks} /><primitive object={clods} />
      {showSky && <mesh position={camPos} scale={[1, 1, 1]}><sphereGeometry args={[600, 24, 16]} /><meshBasicMaterial map={skyTex()} side={THREE.BackSide} fog={false} depthWrite={false} /></mesh>}
      {mounds.map(([x, z, r, h], i) => <mesh key={i} geometry={sph(1, 20, 12)} material={i % 2 ? M.soil : M.soilDark} position={[x, 0, z]} scale={[r, h, r * 0.8]} receiveShadow castShadow />)}
      {/* spoil heaps where the excavator dumps */}
      <mesh geometry={sph(1, 20, 12)} material={M.soil} position={[PILE_A[0], groundH(PILE_A[0], PILE_A[2]) - 0.05, PILE_A[2]]} scale={[2.3, hA, 2.1]} castShadow receiveShadow />
      <mesh geometry={sph(1, 20, 12)} material={M.soil} position={[PILE_B[0], groundH(PILE_B[0], PILE_B[2]) - 0.05, PILE_B[2]]} scale={[2.3, hB, 2.1]} castShadow receiveShadow />
      {/* site cabin, barriers, cones, pipes, light tower */}
      <group position={[-14, 0, -13]} rotation={[0, 0.35, 0]}>
        <mesh geometry={rbox(7, 2.6, 2.6, 0.05)} material={M.white} position={[0, 1.4, 0]} castShadow receiveShadow />
        <mesh geometry={box(7.1, 0.12, 2.7)} material={M.steel} position={[0, 2.75, 0]} castShadow />
        <mesh geometry={box(1.4, 0.8, 0.04)} material={M.glass} position={[1.5, 1.7, 1.31]} />
        <mesh geometry={box(0.9, 1.9, 0.05)} material={M.steelLight} position={[-2.2, 1.15, 1.31]} />
      </group>
      <group position={[-10, 0, -20]} rotation={[0, 0.5, 0]}>{[0, 1, 2].map(i => <mesh key={i} geometry={cyl(0.55, 0.55, 3, 20)} material={M.concrete} position={[i * 1.2, 0.55, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow />)}</group>
      {Array.from({ length: 12 }, (_, i) => <group key={i} position={[-9 + i * 2.1, 0, 9]}>
        <mesh geometry={rbox(2.0, 0.9, 0.5, 0.04)} material={M.concrete} position={[0, 0.45, 0]} castShadow receiveShadow />
        <mesh geometry={box(2.02, 0.2, 0.52)} material={i % 2 ? M.hazard : M.rubber} position={[0, 0.75, 0]} />
      </group>)}
      {cones.map(([x, z], i) => <group key={i} position={[x, 0, z]}><mesh geometry={CONE} material={M.glove} position={[0, 0.38, 0]} castShadow /><mesh geometry={box(0.5, 0.05, 0.5)} material={M.rubber} position={[0, 0.03, 0]} /></group>)}
      <group position={[16, 0, -12]}><mesh geometry={cyl(0.08, 0.1, 6, 8)} material={M.steel} position={[0, 3, 0]} castShadow /><mesh geometry={box(1.4, 0.7, 0.2)} material={M.steelLight} position={[0, 6, 0]} /></group>
    </group>
  );
}
