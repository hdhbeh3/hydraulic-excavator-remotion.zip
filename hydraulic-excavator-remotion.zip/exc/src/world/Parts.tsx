import React, { useMemo } from 'react';
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { M, box, rbox, cyl, sph, Seg, Hose, UNIT_CYL } from './common';
import { Machine, V3, L } from '../world';
import { Cuts, Flows } from '../cutaways';
import { ramp, smooth, clamp } from '../timeline';

const X = Math.PI / 2;

// ================= POWER PACK: engine -> pump, tank, control valve, pilot lines =================
export function PowerPack({ cuts, fl, t }: { cuts: Cuts; fl: Flows; t: number }) {
  const open = cuts.cover < 0.5;
  const startK = t >= 21.05 && t < 22.3 ? 0.25 + 0.75 * smooth((t - 21.05) / 1.25) : fl.run;
  const spin = (t - 21) * 18 * startK;
  const shake = 0.007 * startK * (t > 21 ? 1 : 0.3);
  const jx = Math.sin(t * 97) * shake, jy = Math.sin(t * 83 + 1) * shake;
  const e = L.engine, p = L.pump, v = L.valve, tk = L.tank;
  const f = fl.pump;
  const hc = cuts.hose;
  return (
    <group>
      <group position={[jx, jy, 0]}>
        <mesh geometry={rbox(1.0, 0.7, 0.75, 0.05)} material={M.steel} position={[e[0], e[1] - 0.05, e[2]]} castShadow />
        <mesh geometry={rbox(0.95, 0.18, 0.7, 0.04)} material={M.red} position={[e[0], e[1] + 0.38, e[2]]} castShadow />
        {[-0.3, -0.1, 0.1, 0.3].map(z => <mesh key={z} geometry={cyl(0.07, 0.07, 0.3, 12)} material={M.steelLight} position={[e[0] - 0.1, e[1] + 0.55, z]} castShadow />)}
        <mesh geometry={cyl(0.1, 0.1, 0.9, 14)} material={M.steelLight} position={[e[0] - 0.1, e[1] + 0.2, 0.43]} rotation={[X, 0, 0]} />
        <mesh geometry={cyl(0.3, 0.3, 0.32, 24)} material={M.cast} position={[e[0] + 0.62, e[1] - 0.05, 0]} rotation={[0, 0, X]} castShadow />
        {/* exhaust */}
        <mesh geometry={cyl(0.07, 0.07, 0.9, 12)} material={M.steelLight} position={[e[0] - 0.2, e[1] + 0.95, 0.55]} />
        {/* fan + radiator at the rear */}
        <mesh geometry={rbox(0.22, 0.9, 1.5, 0.04)} material={M.steel} position={[-1.5, 1.8, 0]} castShadow />
        <group position={[-1.34, 1.8, 0]} rotation={[spin * 1.2, 0, 0]}>
          {[0, 1, 2, 3, 4, 5].map(i => <mesh key={i} geometry={box(0.02, 0.38, 0.1)} material={M.rubber} position={[0, 0, 0]} rotation={[i * (Math.PI / 3), 0, 0.3]} />)}
          <mesh geometry={cyl(0.06, 0.06, 0.06, 12)} material={M.steelLight} rotation={[0, 0, X]} />
        </group>
      </group>
      {/* hydraulic main pump: swash-plate axial piston pump, driven by the engine shaft */}
      <mesh geometry={cyl(0.28, 0.28, 0.5, 28, false)} material={open && cuts.hose > 0.5 ? M.ghost : M.steelLight} position={[p[0], p[1], p[2]]} rotation={[0, 0, X]} castShadow />
      <mesh geometry={cyl(0.1, 0.1, 0.4, 14)} material={M.chrome} position={[p[0] - 0.4, p[1], p[2]]} rotation={[0, 0, X]} />
      <group position={[p[0], p[1], p[2]]} rotation={[spin, 0, 0]}>
        {Array.from({ length: 7 }, (_, i) => {
          const ph = (i * 2 * Math.PI) / 7; const ax = 0.05 * Math.sin(spin * 0 + ph);
          return <mesh key={i} geometry={cyl(0.04, 0.04, 0.3, 10)} material={M.chrome} position={[ax, 0.15 * Math.cos(ph), 0.15 * Math.sin(ph)]} rotation={[0, 0, X]} />;
        })}
      </group>
      <mesh geometry={cyl(0.19, 0.19, 0.16, 20)} material={M.steel} position={[p[0] + 0.28, p[1], p[2]]} rotation={[0, 0, X]} />
      {/* reservoir (hydraulic tank) */}
      <mesh geometry={rbox(1.0, 0.8, 0.5, 0.05)} material={open ? M.ghost : M.steel} position={[tk[0], tk[1] - 0.2, tk[2]]} castShadow />
      <mesh geometry={box(0.94, 0.5, 0.44)} material={M.amberSoft} position={[tk[0], tk[1] - 0.35, tk[2]]} />
      {/* main control valve block: spool sections direct oil to each cylinder */}
      <mesh geometry={rbox(0.7, 0.42, 0.6, 0.03)} material={M.steelLight} position={[v[0], v[1] - 0.05, v[2]]} castShadow />
      {[0, 1, 2, 3, 4, 5].map(i => <mesh key={i} geometry={box(0.06, 0.34, 0.62)} material={i % 2 ? M.yellowDark : M.steel} position={[v[0] - 0.27 + i * 0.108, v[1] + 0.2, v[2]]} castShadow />)}
      {[0, 1, 2, 3, 4, 5].map(i => <mesh key={'c' + i} geometry={cyl(0.03, 0.03, 0.06, 8)} material={cuts.pilot > 0.5 ? M.cyan : M.red} position={[v[0] - 0.27 + i * 0.108, v[1] + 0.4, v[2] - 0.2]} />)}
      {/* circuit: Reservoir -> pump -> control valve -> (cylinders, see Arm) -> return -> reservoir */}
      <Hose pts={[[tk[0] - 0.2, tk[1] - 0.55, tk[2] - 0.2], [0.0, 1.45, 0.5], [p[0], 1.45, 0.25], [p[0], p[1] - 0.1, 0.2]]} r={0.07} cut={hc} flow={f} t={t} />
      <Hose pts={[[p[0] + 0.3, p[1] + 0.1, 0.05], [0.0, 2.05, 0.0], [0.2, 2.1, -0.05], [v[0] - 0.2, v[1] + 0.35, v[2]]]} r={0.07} cut={hc} flow={f} pressure t={t} />
      <Hose pts={[[v[0] + 0.25, v[1] - 0.2, v[2] + 0.25], [0.65, 1.5, 0.5], [0.7, 1.5, 0.8], [tk[0] + 0.3, tk[1] - 0.55, tk[2] - 0.2]]} r={0.07} cut={hc} flow={f * 0.8} t={t} />
      {/* pilot (joystick) lines: low-pressure control signals, NOT the main oil */}
      {[L.joyL, L.joyR].map((j, i) => <Hose key={i} pts={[[j[0] - 0.05, 1.45, j[2]], [0.85, 1.3, j[2] * 0.5], [v[0] + 0.2 * i, v[1] + 0.15, v[2] - 0.3]]} r={0.018} cut={cuts.pilot} flow={Math.max(Math.abs(fl.boom), Math.abs(fl.stick), Math.abs(fl.swing)) * (i ? Math.abs(fl.boom) + Math.abs(fl.bucket) : Math.abs(fl.stick) + Math.abs(fl.swing)) + 0.2 * cuts.pilot} pressure t={t} speed={1.4} />)}
    </group>
  );
}

// ================= CAB: glass, seat, joysticks and operator hands =================
const tilt = (v: number) => Math.max(-1, Math.min(1, v)) * 0.33;
function Joystick({ pos, tx, tz }: { pos: V3; tx: number; tz: number }) {
  const h = 0.26;
  const tip: V3 = [pos[0] + h * Math.sin(tx), pos[1] + h * Math.cos(tx) * Math.cos(tz), pos[2] + h * Math.sin(tz)];
  return (
    <group>
      <mesh geometry={rbox(0.22, 0.3, 0.3, 0.04)} material={M.steel} position={[pos[0], pos[1] - 0.17, pos[2]]} castShadow />
      <mesh geometry={cyl(0.05, 0.05, 0.05, 14)} material={M.rubber} position={[pos[0], pos[1] + 0.01, pos[2]]} />
      <group position={pos} rotation={[tz, 0, -tx]}>
        <mesh geometry={cyl(0.017, 0.017, 0.22, 10)} material={M.steelLight} position={[0, 0.11, 0]} castShadow />
        <mesh geometry={sph(0.045, 14, 10)} material={M.rubber} position={[0, 0.24, 0]} castShadow />
      </group>
      {/* gloved hand wrapped over the grip */}
      <group position={tip} rotation={[tz * 0.6, 0, -tx * 0.6]}>
        <mesh geometry={rbox(0.12, 0.06, 0.11, 0.025)} material={M.glove} position={[-0.015, 0.045, 0]} castShadow />
        {[-0.036, -0.012, 0.012, 0.036].map(z => <mesh key={z} geometry={rbox(0.07, 0.025, 0.022, 0.01)} material={M.glove} position={[0.045, 0.01, z]} />)}
        <mesh geometry={rbox(0.05, 0.03, 0.03, 0.01)} material={M.glove} position={[0.02, 0.06, 0.06 * Math.sign(pos[2] + 0.8)]} />
      </group>
      <Seg a={[tip[0] - 0.07, tip[1] + 0.06, tip[2]]} b={[0.42, 2.12, pos[2] + 0.06 * Math.sign(pos[2] + 0.8)]} r={0.042} mat={M.sleeve} />
    </group>
  );
}
export function Cab({ cuts, fl, t }: { cuts: Cuts; fl: Flows; t: number }) {
  const g = cuts.cabGhost;
  const body = g > 0.5 ? M.ghost : M.yellow;
  const c = L.cab;
  return (
    <group>
      <mesh geometry={box(1.2, 0.08, 0.95)} material={M.steel} position={[0.9, 1.34, -0.82]} receiveShadow />
      {[[0.3, -0.35], [0.3, -1.28], [1.5, -0.35], [1.5, -1.28]].map(([x, z], i) => <mesh key={i} geometry={box(0.07, 1.7, 0.07)} material={body} position={[x, 2.2, z]} castShadow />)}
      <mesh geometry={rbox(1.35, 0.09, 1.1, 0.03)} material={body} position={[0.9, 3.08, -0.82]} castShadow />
      <mesh geometry={box(1.2, 1.5, 0.02)} material={M.glass} position={[0.9, 2.2, -1.28]} />
      <mesh geometry={box(1.2, 1.5, 0.02)} material={M.glass} position={[0.9, 2.2, -0.36]} />
      <mesh geometry={box(0.02, 1.5, 0.9)} material={M.glass} position={[1.5, 2.2, -0.82]} />
      <mesh geometry={box(0.04, 1.0, 0.9)} material={g > 0.5 ? M.ghost : M.yellowDark} position={[0.3, 1.9, -0.82]} />
      <mesh geometry={rbox(0.5, 0.12, 0.5, 0.04)} material={M.rubber} position={[0.6, 1.62, -0.82]} castShadow />
      <mesh geometry={rbox(0.1, 0.55, 0.48, 0.04)} material={M.rubber} position={[0.38, 1.92, -0.82]} castShadow />
      <mesh geometry={box(0.3, 0.3, 0.9)} material={M.steel} position={[0.99, 1.5, -0.82]} />
      <Joystick pos={[1.0, 1.82, -1.08]} tx={tilt(fl.stick)} tz={tilt(fl.swing)} />
      <Joystick pos={[1.0, 1.82, -0.52]} tx={tilt(-fl.boom)} tz={tilt(fl.bucket)} />
    </group>
  );
}

// ================= UNDERCARRIAGE: tracks, sprockets, hydraulic travel motors, planetary gearboxes =================
const R = 0.45, STR = 3.4, ARC = Math.PI * R, PER = 2 * STR + 2 * ARC, NLINK = 48;
function trackPoint(s: number): { x: number; y: number; a: number } {
  let d = ((s % PER) + PER) % PER;
  if (d < STR) return { x: 1.7 - d, y: 0.1, a: Math.PI };
  d -= STR;
  if (d < ARC) { const th = 1.5 * Math.PI - d / R; return { x: -1.7 + R * Math.cos(th), y: 0.55 + R * Math.sin(th), a: Math.atan2(-Math.cos(th), Math.sin(th)) }; }
  d -= ARC;
  if (d < STR) return { x: -1.7 + d, y: 1.0, a: 0 };
  d -= STR;
  const th = Math.PI / 2 - d / R; return { x: 1.7 + R * Math.cos(th), y: 0.55 + R * Math.sin(th), a: Math.atan2(-Math.cos(th), Math.sin(th)) };
}
let LINK: THREE.BufferGeometry | null = null;
const linkGeo = () => {
  if (LINK) return LINK;
  const a = new THREE.BoxGeometry(0.19, 0.05, 0.56);
  const b = new THREE.BoxGeometry(0.11, 0.05, 0.5); b.translate(0, 0.05, 0);
  const c = new THREE.CylinderGeometry(0.03, 0.03, 0.58, 8); c.rotateX(X); c.translate(0.095, 0, 0);
  LINK = mergeGeometries([a, b, c])!; return LINK;
};
const sprocketTeeth = Array.from({ length: 18 }, (_, i) => (i / 18) * Math.PI * 2);

export function Undercarriage({ m, cuts, fl, t }: { m: Machine; cuts: Cuts; fl: Flows; t: number }) {
  const D = m.travel; const wheel = -D / 0.4; const gear = cuts.gear > 0.02;
  const links = useMemo(() => Array.from({ length: NLINK }, (_, i) => i * (PER / NLINK)), []);
  const geo = linkGeo();
  const sides = [-1, 1];
  const mot = Math.max(fl.travel, 0);
  const sun = 4 * wheel, car = wheel, pl = -3 * wheel;
  const teeth = (n: number, r: number, mat: THREE.Material, sz: number) => Array.from({ length: n }, (_, i) => { const a = (i / n) * Math.PI * 2; return <mesh key={i} geometry={box(sz, sz * 1.5, 0.1)} material={mat} position={[r * Math.cos(a), r * Math.sin(a), 0]} rotation={[0, 0, a]} />; });
  return (
    <group>
      <mesh geometry={rbox(2.6, 0.5, 1.6, 0.06)} material={M.cast} position={[-0.1, 0.85, 0]} castShadow receiveShadow />
      {sides.map(s => <React.Fragment key={s}>
        <mesh geometry={rbox(1.2, 0.4, 0.45, 0.04)} material={M.cast} position={[0, 0.8, s * 0.95]} castShadow />
        <mesh geometry={rbox(2.8, 0.4, 0.45, 0.05)} material={M.steel} position={[0, 0.58, s * 1.12]} castShadow receiveShadow />
        {[-1.0, -0.5, 0, 0.5, 1.0].map((x, i) => <group key={i} position={[x, 0.27, s * 1.12]} rotation={[0, 0, -D / 0.17]}>
          <mesh geometry={cyl(0.17, 0.17, 0.32, 14)} material={M.steelLight} rotation={[X, 0, 0]} castShadow /><mesh geometry={box(0.05, 0.3, 0.34)} material={M.steel} /></group>)}
        {[-0.6, 0.6].map((x, i) => <group key={'c' + i} position={[x, 0.93, s * 1.12]} rotation={[0, 0, -D / 0.1]}><mesh geometry={cyl(0.1, 0.1, 0.3, 12)} material={M.steelLight} rotation={[X, 0, 0]} castShadow /></group>)}
        {/* idler (front) and sprocket (rear) */}
        <group position={[1.7, 0.55, s * 1.12]} rotation={[0, 0, wheel * 0.95]}><mesh geometry={cyl(0.4, 0.4, 0.32, 24)} material={M.steelLight} rotation={[X, 0, 0]} castShadow /><mesh geometry={box(0.1, 0.7, 0.34)} material={M.steel} /></group>
        <group position={[-1.7, 0.55, s * 1.12]} rotation={[0, 0, wheel]}>
          <mesh geometry={cyl(0.36, 0.36, 0.3, 24)} material={M.steelLight} rotation={[X, 0, 0]} castShadow />
          {sprocketTeeth.map((a, i) => <mesh key={i} geometry={box(0.1, 0.09, 0.3)} material={M.steelLight} position={[0.4 * Math.cos(a), 0.4 * Math.sin(a), 0]} rotation={[0, 0, a]} castShadow />)}
        </group>
        {/* track links */}
        {links.map((s0, i) => { const p = trackPoint(s0 + D); return <mesh key={i} geometry={geo} material={i % 2 ? M.track : M.grouser} position={[p.x, p.y, s * 1.12]} rotation={[0, 0, p.a]} castShadow receiveShadow />; })}
        {/* final-drive housing + hydraulic travel motor */}
        <mesh geometry={cyl(0.34, 0.34, 0.32, 28)} material={gear ? M.ghost : M.yellowDark} position={[-1.7, 0.55, s * 1.59]} rotation={[X, 0, 0]} castShadow />
        <mesh geometry={cyl(0.22, 0.22, 0.4, 22)} material={M.steelLight} position={[-1.7, 0.55, s * 1.95]} rotation={[X, 0, 0]} castShadow />
        <mesh geometry={sph(0.2, 14, 10)} material={M.red} position={[-1.7, 0.55, s * 2.17]} />
        <Hose pts={[[-1.55, 0.75, s * 1.95], [-1.3, 1.0, s * 1.6], [-1.0, 1.12, s * 1.0], [-0.6, 1.1, s * 0.5]]} r={0.05} cut={cuts.gear} flow={mot} pressure t={t} />
        <Hose pts={[[-1.85, 0.75, s * 1.95], [-1.6, 1.15, s * 1.6], [-1.2, 1.25, s * 1.0], [-0.7, 1.2, s * 0.55]]} r={0.05} cut={cuts.gear} flow={-mot} t={t} />
      </React.Fragment>)}
      {/* planetary reduction gearbox (visible when the housing turns transparent) */}
      {gear && <group position={[-1.7, 0.55, -1.59]}>
        <mesh geometry={cyl(0.31, 0.31, 0.1, 40, true)} material={M.steelLight} rotation={[X, 0, 0]} />
        <group>{teeth(36, 0.27, M.steelLight, 0.02)}</group>
        <group rotation={[0, 0, sun]}><mesh geometry={cyl(0.06, 0.06, 0.1, 16)} material={M.chrome} rotation={[X, 0, 0]} />{teeth(12, 0.075, M.chrome, 0.026)}</group>
        <group rotation={[0, 0, car]}>
          <mesh geometry={cyl(0.26, 0.26, 0.03, 32)} material={M.cyanSoft} position={[0, 0, 0.07]} rotation={[X, 0, 0]} />
          {[0, 1, 2].map(i => { const a = (i * 2 * Math.PI) / 3; return <group key={i} position={[0.165 * Math.cos(a), 0.165 * Math.sin(a), 0]} rotation={[0, 0, pl]}>
            <mesh geometry={cyl(0.092, 0.092, 0.1, 18)} material={M.yellow} rotation={[X, 0, 0]} />{teeth(12, 0.105, M.yellow, 0.026)}</group>; })}
        </group>
      </group>}
    </group>
  );
}
