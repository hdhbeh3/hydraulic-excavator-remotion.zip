// Pure 2D (side-plane) excavator kinematics. House frame: x forward, y up. Units: metres. Angles: degrees in API.
export type V2 = [number, number];
const D2R = Math.PI / 180;
export const rot = (p: V2, a: number): V2 => [p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a)];
export const add = (a: V2, b: V2): V2 => [a[0] + b[0], a[1] + b[1]];
export const sub = (a: V2, b: V2): V2 => [a[0] - b[0], a[1] - b[1]];
export const len = (a: V2) => Math.hypot(a[0], a[1]);

export const G = {
  P0: [0.85, 1.55] as V2,
  Lb: 4.7,
  Ls: 2.35,
  Lt: 1.25,
  boomCylBase: [1.55, 0.98] as V2,
  boomCylRod: [1.75, -0.2] as V2,
  stickCylBase: [3.1, 0.9] as V2,
  stickCylRod: [-0.25, 0.68] as V2,
  bktCylBase: [0.5, 0.5] as V2,
  stickLinkPin: [2.0, 0.16] as V2,
  bktLinkPin: [0.1, 0.5] as V2,
  l1: 0.44,
  l2: 0.6,
};

export interface Arm {
  a1: number; a2: number; a3: number;
  P0: V2; E: V2; K: V2; tip: V2;
  boomCyl: { a: V2; b: V2 };
  stickCyl: { a: V2; b: V2 };
  bktCyl: { a: V2; b: V2 };
  J: V2; S2: V2; Lk: V2;
}

function circleIntersect(c0: V2, r0: number, c1: V2, r1: number, pick: 1 | -1): V2 {
  const d = len(sub(c1, c0));
  const dd = Math.min(Math.max(d, Math.abs(r0 - r1) + 1e-6), r0 + r1 - 1e-6);
  const a = (r0 * r0 - r1 * r1 + dd * dd) / (2 * dd);
  const h = Math.sqrt(Math.max(r0 * r0 - a * a, 0));
  const ux = (c1[0] - c0[0]) / d, uy = (c1[1] - c0[1]) / d;
  return [c0[0] + a * ux - pick * h * uy, c0[1] + a * uy + pick * h * ux];
}

export function solveArm(boomDeg: number, stickDeg: number, bucketDeg: number): Arm {
  const a1 = boomDeg * D2R;
  const a2 = a1 - stickDeg * D2R;
  const a3 = a2 - bucketDeg * D2R;
  const P0 = G.P0;
  const E = add(P0, rot([G.Lb, 0], a1));
  const K = add(E, rot([G.Ls, 0], a2));
  const tip = add(K, rot([G.Lt, 0], a3));
  const boomCyl = { a: G.boomCylBase, b: add(P0, rot(G.boomCylRod, a1)) };
  const stickCyl = { a: add(P0, rot(G.stickCylBase, a1)), b: add(E, rot(G.stickCylRod, a2)) };
  const S2 = add(E, rot(G.stickLinkPin, a2));
  const Lk = add(K, rot(G.bktLinkPin, a3));
  const J = circleIntersect(S2, G.l1, Lk, G.l2, 1);
  const bktBase = add(E, rot(G.bktCylBase, a2));
  return { a1, a2, a3, P0, E, K, tip, boomCyl, stickCyl, bktCyl: { a: bktBase, b: J }, J, S2, Lk };
}

export const LIM = { boom: [-12, 62] as V2, stick: [12, 125] as V2, bucket: [8, 150] as V2 };

export interface CylSpec { min: number; max: number; rod: number; barrel: number }
function sample(f: (a: Arm) => { a: V2; b: V2 }, bR: V2, sR: V2, kR: V2): CylSpec {
  let mn = 1e9, mx = 0;
  for (let i = 0; i <= 12; i++) for (let j = 0; j <= 12; j++) for (let k = 0; k <= 12; k++) {
    const arm = solveArm(bR[0] + (bR[1] - bR[0]) * i / 12, sR[0] + (sR[1] - sR[0]) * j / 12, kR[0] + (kR[1] - kR[0]) * k / 12);
    const c = f(arm); const d = len(sub(c.b, c.a)); mn = Math.min(mn, d); mx = Math.max(mx, d);
  }
  const rod = mn * 0.82;
  return { min: mn, max: mx, rod, barrel: mx - rod + 0.06 };
}
export const SPEC = {
  boom: sample(a => a.boomCyl, LIM.boom, [60, 60], [60, 60]),
  stick: sample(a => a.stickCyl, [30, 30], LIM.stick, [60, 60]),
  bucket: sample(a => a.bktCyl, [30, 30], [60, 60], LIM.bucket),
};
