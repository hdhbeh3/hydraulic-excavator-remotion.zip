import React from 'react';
import { Composition } from 'remotion';
import { Video } from './Video';
import { FPS, WIDTH, HEIGHT, DURATION_FRAMES } from './timeline';

export const RemotionRoot: React.FC = () => (
  <Composition id="HydraulicExcavator" component={Video} durationInFrames={DURATION_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
