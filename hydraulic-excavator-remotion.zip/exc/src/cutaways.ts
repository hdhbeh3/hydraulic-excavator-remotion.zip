// When the machine "opens up": all cutaway amounts are driven from here so visuals stay locked to the narration.
import { ramp, win, clamp } from './timeline';
import { machineAt } from './world';
import { solveArm, len, sub, SPEC } from './kinematics';
import { poseAt } from './timeline';

const pulse = (t: number, a: number, b: number, c: number, d: number) => ramp(t, a, b) * (1 - ramp(t, c, d));
const max = Math.max;

export interface Cuts { cover: number; cyl: number; hose: number; gear: number; cabGhost: number; pilot: number; balance: number }
export function cutsAt(t: number): Cuts {
  return {
    cover: 1 - 0.96 * pulse(t, 20.9, 21.5, 26.3, 26.8) - 0.96 * pulse(t, 62.8, 63.1, 65.0, 65.4),
    cyl: max(pulse(t, 26.3, 26.7, 32.3, 32.7), pulse(t, 34.2, 34.5, 37.7, 38.0)),
    hose: max(pulse(t, 22.9, 23.2, 32.3, 32.7), max(pulse(t, 34.2, 34.5, 37.7, 38.0), pulse(t, 62.9, 63.2, 65.0, 65.4))),
    gear: pulse(t, 52.6, 53.1, 56.3, 56.8),
    cabGhost: max(pulse(t, 57.95, 58.15, 58.95, 59.1), pulse(t, 59.6, 59.8, 61.65, 61.85)),
    pilot: pulse(t, 62.9, 63.2, 65.0, 65.4),
    balance: max(pulse(t, 44.7, 45.2, 47.0, 47.5), pulse(t, 49.5, 49.9, 51.5, 51.95)),
  };
}

export interface Flows { run: number; demand: number; boom: number; stick: number; bucket: number; swing: number; pump: number; travel: number }
/** Signed, normalised hydraulic activity from real cylinder length rates (extend > 0). */
export function flowsAt(t: number): Flows {
  const h = 0.06;
  const a0 = machineAt(Math.max(0, t - h)), a1 = machineAt(t + h);
  const L = (m: ReturnType<typeof machineAt>, k: 'boomCyl' | 'stickCyl' | 'bktCyl') => len(sub(m.arm[k].b, m.arm[k].a));
  const v = (k: 'boomCyl' | 'stickCyl' | 'bktCyl') => (L(a1, k) - L(a0, k)) / (2 * h);
  const norm = (x: number) => Math.max(-1, Math.min(1, x / 0.8));
  const boomRaw = norm(v('boomCyl'));
  const boom = Math.max(boomRaw, 0.7 * pulse(t, 26.5, 26.75, 27.95, 28.1), 0.6 * pulse(t, 28.0, 28.15, 29.5, 29.65));
  const stick = norm(v('stickCyl')), bucket = norm(v('bktCyl'));
  const swing = Math.max(-1, Math.min(1, (a1.pose.swing - a0.pose.swing) / (2 * h) / 60));
  const run = poseAt(t).engineRun;
  const travel = Math.min(1, Math.abs(a1.pose.travel - a0.pose.travel) / (2 * h) / 1.0);
  const demand = clamp(max(max(Math.abs(boom), Math.abs(stick)), max(Math.abs(bucket), max(Math.abs(swing), travel))), 0, 1);
  const pump = Math.max(run * (0.3 + 0.7 * demand), 0.9 * pulse(t, 23.0, 23.3, 26.6, 26.9));
  return { run, demand, boom, stick, bucket, swing, pump, travel };
}
export { SPEC };
