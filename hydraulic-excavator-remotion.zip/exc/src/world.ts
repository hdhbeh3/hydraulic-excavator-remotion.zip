// Pure-math world state shared by the 3D scene and the camera director (no three.js import => unit-testable in Node).
import { poseAt, Pose, smooth, smoother, ramp, clamp, lerp } from './timeline';
import { solveArm, Arm } from './kinematics';

export type V3 = [number, number, number];
export const MACH_X0 = -2.0;
export const TABLE: V3 = [-90, 0, 0]; // tabletop experiment lives far from the site
export const PILE_A: V3 = [MACH_X0 + 2.4, 0, -6.5];
export const PILE_B: V3 = [MACH_X0 + 4.2 + 2.4, 0, -6.5];
export const PIT_A: V3 = [MACH_X0 + 6.2, 0, 0];
export const PIT_B: V3 = [MACH_X0 + 4.2 + 6.2, 0, 0];
export const ROCK: V3 = [MACH_X0 + 7.6, 0.6, 0];

export function groundH(x: number, z: number): number {
  const amp = 0.03 + 0.2 * ramp(x, 1.2, 4.0) * (1 - 0.6 * smooth(Math.abs(z) / 6));
  const far = 1 + 0.5 * smooth((Math.hypot(x, z) - 14) / 20);
  return (Math.sin(x * 0.83 + 1.3) * Math.cos(z * 0.57 + 0.4) * 0.55 + Math.sin(x * 2.1 + z * 1.7) * 0.25 + Math.sin(z * 1.3 - x * 0.7) * 0.2) * amp * far;
}

const TRACK_HALF = 1.8; // half base length used for terrain tilt
export interface Machine { x: number; y: number; pitch: number; swing: number; pose: Pose; arm: Arm; travel: number }

export function machineAt(t: number): Machine {
  const pose = poseAt(t);
  const x = MACH_X0 + pose.travel;
  const hF = (groundH(x + TRACK_HALF, -1.1) + groundH(x + TRACK_HALF, 1.1)) / 2;
  const hR = (groundH(x - TRACK_HALF, -1.1) + groundH(x - TRACK_HALF, 1.1)) / 2;
  const terrainPitch = Math.atan2(hF - hR, TRACK_HALF * 2);
  const loadPitch = (pose.pitch * Math.PI) / 180; // nose-down tipping tendency
  return { x, y: (hF + hR) / 2, pitch: terrainPitch - loadPitch, swing: (pose.swing * Math.PI) / 180, pose, arm: solveArm(pose.boom, pose.stick, pose.bucket), travel: pose.travel };
}

/** house-local point -> world point */
export function toWorld(m: Machine, p: V3): V3 {
  const c = Math.cos(m.swing), s = Math.sin(m.swing);
  const x = p[0] * c + p[2] * s, z = -p[0] * s + p[2] * c;
  return [m.x + x, m.y + p[1] + x * Math.sin(m.pitch), z];
}
/** machine-local (undercarriage frame, no swing) -> world */
export function toWorldUC(m: Machine, p: V3): V3 { return [m.x + p[0], m.y + p[1] + p[0] * Math.sin(m.pitch), p[2]]; }

export const L = { // house-local component positions (single source of truth for model + camera)
  engine: [-1.05, 1.7, 0] as V3, pump: [-0.25, 1.65, 0.0] as V3, valve: [0.45, 1.7, -0.1] as V3,
  tank: [0.4, 1.85, 0.95] as V3, counterweight: [-2.0, 1.6, 0] as V3, cab: [0.9, 2.3, -0.8] as V3,
  joyL: [1.0, 1.92, -1.08] as V3, joyR: [1.0, 1.92, -0.52] as V3,
};

export type AnchorName = string;
export function anchors(t: number): Record<AnchorName, V3> {
  const m = machineAt(t); const a = m.arm;
  const w = (p: V3) => toWorld(m, p);
  const mid = (p: [number, number], q: [number, number]): V3 => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2, 0];
  const tip = w([a.tip[0], a.tip[1], 0]);
  const hs = w([0.4, 1.8, 0]);
  const rock: V3 = m.pose.rockAttach > 0.5 ? w([a.tip[0] - 0.35, a.tip[1] + 0.62, 0]) : [ROCK[0], ROCK[1] + groundH(ROCK[0], 0), ROCK[2]];
  return {
    house: w([0, 2.0, 0]), engine: w(L.engine), pump: w(L.pump), valve: w(L.valve), tank: w(L.tank),
    counterweight: w(L.counterweight), cab: w(L.cab), joysticks: w([1.0, 1.95, -0.8]), joyL: w(L.joyL), joyR: w(L.joyR),
    boomCylMid: w(mid(a.boomCyl.a, a.boomCyl.b)), stickCylMid: w(mid(a.stickCyl.a, a.stickCyl.b)),
    bktCylMid: w(mid(a.bktCyl.a, a.bktCyl.b)),
    bucketTip: tip, bucketK: w([a.K[0], a.K[1], 0]), boomElbow: w([a.E[0], a.E[1], 0]),
    workArea: w([(a.P0[0] + a.tip[0]) / 2, (a.P0[1] + a.tip[1]) / 2 + 0.3, 0]),
    rock,
    undercarriage: toWorldUC(m, [0, 0.8, 0]), trackFront: toWorldUC(m, [1.7, 0.6, 0]), trackRear: toWorldUC(m, [-1.7, 0.6, 0]),
    motorL: toWorldUC(m, [-1.7, 0.6, -1.45]), sprocketL: toWorldUC(m, [-1.7, 0.55, -1.1]), trackL: toWorldUC(m, [0, 0.5, -1.1]),
    tableSyringeA: [TABLE[0] - 2.0, 0.45, 0], tableMid: [TABLE[0], 0.5, 0], tableB: [TABLE[0] + 0.65, 0.5 + 7 * smoother((t - 8.7) / 1.6), 0],
    pitA: [PIT_A[0], 0.3, 0], pileA: [PILE_A[0], 0.8, PILE_A[2]], hs,
  };
}
export const lerp3 = (a: V3, b: V3, t: number): V3 => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
