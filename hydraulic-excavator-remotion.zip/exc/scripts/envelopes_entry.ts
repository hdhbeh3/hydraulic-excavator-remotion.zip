import { flowsAt, cutsAt } from '../src/cutaways';
import { machineAt } from '../src/world';
import { SHOTS } from '../src/camera';
const out: any = { rate: 50, demand: [], pump: [], boom: [], stick: [], bucket: [], swing: [], travel: [], travelSpeed: [], run: [], strain: [], hose: [], pilot: [], shots: SHOTS.map(s => [s.t0, s.t1, !!s.whip]) };
const N = Math.ceil(69.8 * 50);
for (let i = 0; i <= N; i++) {
  const t = i / 50; const f = flowsAt(t); const c = cutsAt(t); const m = machineAt(t); const m2 = machineAt(t + 0.04);
  out.demand.push(+f.demand.toFixed(3)); out.pump.push(+f.pump.toFixed(3)); out.boom.push(+f.boom.toFixed(3)); out.stick.push(+f.stick.toFixed(3));
  out.bucket.push(+f.bucket.toFixed(3)); out.swing.push(+f.swing.toFixed(3)); out.travel.push(+f.travel.toFixed(3));
  out.travelSpeed.push(+((m2.travel - m.travel) / 0.04).toFixed(3)); out.run.push(+f.run.toFixed(3)); out.strain.push(+m.pose.strain.toFixed(3));
  out.hose.push(+c.hose.toFixed(3)); out.pilot.push(+c.pilot.toFixed(3));
}
console.log(JSON.stringify(out));
