// Project self-check: files, composition, duration, audio, SFX/camera sync, no on-screen text. Run: npm run verify
import { readFileSync, existsSync, statSync, readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const J = p => JSON.parse(readFileSync(p, 'utf8'));
const tl = J('src/data/timeline.json'), env = J('src/data/envelopes.json');

for (const f of ['package.json', 'tsconfig.json', 'remotion.config.ts', 'src/index.ts', 'src/Root.tsx', 'src/Video.tsx', 'src/timeline.ts', 'src/world.ts', 'src/camera.ts', 'src/kinematics.ts', 'src/cutaways.ts',
  'src/world/Excavator.tsx', 'src/world/Parts.tsx', 'src/world/Syringes.tsx', 'src/world/Site.tsx', 'src/world/Effects.tsx', 'src/world/common.tsx',
  'public/voiceover.mp3', 'public/audio/music.mp3', 'public/audio/sfx_mechanical.mp3', 'public/audio/sfx_camera.mp3', 'public/audio/sfx_funny.mp3', 'scripts/audio_gen.py', '.github/workflows/render.yml'])
  ok(existsSync(f) && statSync(f).size > 0, `file exists: ${f}`);

const root = readFileSync('src/Root.tsx', 'utf8');
ok(/id="HydraulicExcavator"/.test(root), 'composition id = HydraulicExcavator');
const tsrc = readFileSync('src/timeline.ts', 'utf8');
ok(/WIDTH = 1080/.test(tsrc) && /HEIGHT = 1920/.test(tsrc) && tl.fps === 30, '1080x1920 @ 30 fps');
const frames = Math.ceil(tl.voiceoverSeconds * tl.fps);
ok(frames === 2094, `duration = ceil(${tl.voiceoverSeconds}s x 30) = ${frames} frames`);
try {
  const d = f => parseFloat(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]).toString());
  const v = d('public/voiceover.mp3'); ok(Math.abs(v - tl.voiceoverSeconds) < 0.02, `voiceover.mp3 length ${v.toFixed(2)}s matches timeline`);
  for (const s of ['music', 'sfx_mechanical', 'sfx_camera', 'sfx_funny']) { const x = d(`public/audio/${s}.mp3`); ok(Math.abs(x - frames / 30) < 0.12, `${s}.mp3 length ${x.toFixed(2)}s == video ${(frames / 30).toFixed(2)}s`); }
} catch { console.log('SKIP ffprobe not available - audio length checks skipped'); }

// sentences strictly ordered, inside the voiceover
let ordered = true; tl.sentences.forEach((s, i) => { if (!(s.a < s.b) || (i && s.a < tl.sentences[i - 1].b)) ordered = false; });
ok(ordered && tl.sentences.at(-1).b <= tl.voiceoverSeconds, `${tl.sentences.length} sentence windows ordered and inside the voiceover`);

// camera: contiguous shots covering the whole video
const shots = env.shots; let contiguous = shots[0][0] === 0 && Math.abs(shots.at(-1)[1] - frames / 30) < 0.02;
for (let i = 1; i < shots.length; i++) if (Math.abs(shots[i][0] - shots[i - 1][1]) > 1e-6) contiguous = false;
ok(contiguous, `${shots.length} camera shots are contiguous and cover 0 - ${(frames / 30).toFixed(2)} s`);
// every shot cut that starts a sentence-level story beat lines up with a narration boundary (+-0.12 s) or is a within-sentence cut
const bounds = shots.map(s => s[0]);
const near = (t, arr, tol) => arr.some(x => Math.abs(x - t) <= tol);
const sentStarts = tl.sentences.map(s => s.a), sentEnds = tl.sentences.map(s => s.b);
let beatAligned = 0; bounds.forEach(b => { if (near(b, sentStarts, 0.25) || near(b, sentEnds, 0.25)) beatAligned++; });
ok(beatAligned / bounds.length > 0.7, `${beatAligned}/${bounds.length} camera cuts land on narration sentence boundaries (+-0.25 s); rest are intra-sentence beats`);
// whooshes peak on a cut
let wh = 0, whOK = 0; for (const c of tl.sfx.cam) { if (c.type === 'whoosh_up') continue; wh++; const peak = c.t + 0.5 * c.dur; if (near(peak, bounds, 0.12)) whOK++; }
ok(whOK === wh, `${whOK}/${wh} camera whooshes peak on a camera cut (+-0.12 s)`);
// funny SFX: few, and in narration pauses
let fun = 0; const inSpeech = t => tl.sentences.some(s => t > s.a + 0.12 && t < s.b - 0.05);
tl.sfx.fun.forEach(c => { if (!inSpeech(c.t) || c.type === 'womp') fun++; });
ok(tl.sfx.fun.length <= 6, `funny SFX are sparse (${tl.sfx.fun.length}); ${fun} of them start in or at the edge of a narration pause`);
// SFX never start outside the video
ok([...tl.sfx.mech, ...tl.sfx.cam, ...tl.sfx.fun].every(c => c.t >= 0 && c.t + c.dur <= 69.8 + 0.01), 'all SFX cues fit inside the video');
// no on-screen text
let bad = [];
for (const dir of ['src', 'src/world']) for (const f of readdirSync(dir)) if (/\.(tsx|ts)$/.test(f)) {
  const s = readFileSync(`${dir}/${f}`, 'utf8');
  if (/<Text\b|<Html\b|<text\b|subtitle|caption|<Sequence[^>]*>[^<]*[A-Za-z]{4}/i.test(s.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, ''))) bad.push(f);
}
ok(bad.length === 0, 'no caption / text / HTML-label code in source' + (bad.length ? ': ' + bad : ''));
const pkg = J('package.json'); const rv = pkg.dependencies.remotion;
ok(['@remotion/cli', '@remotion/three'].every(k => pkg.dependencies[k] === rv), `all Remotion packages pinned to the same version (${rv})`);
console.log(fails ? `\n${fails} CHECK(S) FAILED` : '\nALL CHECKS PASSED'); process.exit(fails ? 1 : 0);
