#!/usr/bin/env python3
"""
Generates every audio layer for the Hydraulic Excavator Short from the REAL voiceover + src/data/*.json.
Layers (separate files in public/audio): music.mp3, sfx_mechanical.mp3, sfx_camera.mp3, sfx_funny.mp3
Ducking is derived from the actual voiceover envelope. Voiceover itself is never modified (copied as public/voiceover.mp3).
Requires: python3, numpy, scipy, ffmpeg.   Usage: python3 scripts/audio_gen.py [path/to/voiceover.mp3]
"""
import json, os, subprocess, sys, shutil
import numpy as np
from scipy import signal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 44100
FPS = 30
DUR = 2094 / FPS                      # video length (69.8 s) = ceil(voiceover 69.79 s * 30) frames
N = int(round(DUR * SR))
TL = json.load(open(f'{ROOT}/src/data/timeline.json'))
ENV = json.load(open(f'{ROOT}/src/data/envelopes.json'))
rng = np.random.default_rng(20260622)

def sec(t): return int(round(t * SR))
def env_at(name, t):  # sample 50 Hz envelope arrays at time array t
    a = np.asarray(ENV[name], dtype=np.float64); idx = np.clip(t * ENV['rate'], 0, len(a) - 1)
    return np.interp(idx, np.arange(len(a)), a)
TT = np.arange(N) / SR

# ---------------- filters ----------------
def sos(kind, f, x, order=2):
    f = float(f) if kind in ('low', 'high') else np.asarray(f, dtype=float)
    s = signal.butter(order, f / (SR / 2), btype=kind, output='sos'); return signal.sosfilt(s, x)
def lp(x, f): return sos('low', f, x)
def hp(x, f): return sos('high', f, x)
def bp(x, lo, hi): return sos('band', [lo, hi], x)
def noise(n): return rng.standard_normal(n)
def norm(x, peak=1.0): m = np.max(np.abs(x)) or 1; return x / m * peak
def adsr(n, a, r, curve=1.0):
    e = np.ones(n); na, nr = min(int(a * SR), n // 2), min(int(r * SR), n // 2)
    if na: e[:na] = np.linspace(0, 1, na) ** curve
    if nr: e[-nr:] *= np.linspace(1, 0, nr) ** curve
    return e
def expdecay(n, tau): return np.exp(-np.arange(n) / (tau * SR))
def stereo(x, pan=0.0):
    l = np.sqrt(0.5 * (1 - pan)) ; r = np.sqrt(0.5 * (1 + pan)); return np.stack([x * l * 1.414, x * r * 1.414], 1)
def place(buf, x, t0, gain=1.0):
    i = sec(t0); 
    if i >= buf.shape[0]: return
    if x.ndim == 1: x = stereo(x)
    j = min(buf.shape[0], i + x.shape[0]); buf[i:j] += x[:j - i] * gain
def ph(freq): return 2 * np.pi * np.cumsum(freq) / SR   # phase from instantaneous frequency array
def saw(freq): return signal.sawtooth(ph(freq))

# ---------------- voiceover analysis (ducking comes from the real audio) ----------------
vo_path = sys.argv[1] if len(sys.argv) > 1 else f'{ROOT}/public/voiceover.mp3'
if not os.path.exists(vo_path):
    for c in (f'{ROOT}/voiceover.mp3', '/mnt/user-data/uploads/hydro.mp3'):
        if os.path.exists(c): vo_path = c; break
os.makedirs(f'{ROOT}/public/audio', exist_ok=True)
if os.path.abspath(vo_path) != os.path.abspath(f'{ROOT}/public/voiceover.mp3'): shutil.copyfile(vo_path, f'{ROOT}/public/voiceover.mp3')
raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', vo_path, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True).stdout
vo = np.frombuffer(raw, dtype=np.float32).astype(np.float64)
vo = np.pad(vo, (0, max(0, N - len(vo))))[:N]
hop = int(0.01 * SR)
rms = np.sqrt(np.convolve(vo ** 2, np.ones(hop * 2) / (hop * 2), 'same'))
speech_db = 20 * np.log10(np.sqrt(np.mean(vo[np.abs(vo) > 0.02] ** 2)))
gate = (rms > 10 ** ((speech_db - 20) / 20)).astype(np.float64)
def smooth_follow(x, att, rel):
    a_a = np.exp(-1 / (att * SR)); a_r = np.exp(-1 / (rel * SR)); y = np.zeros_like(x); s = 0.0
    # run at 1 kHz for speed, then interpolate
    step = SR // 1000; xs = x[::step]; ys = np.zeros_like(xs)
    a_a = np.exp(-1 / (att * 1000)); a_r = np.exp(-1 / (rel * 1000))
    for i, v in enumerate(xs):
        s = a_a * s + (1 - a_a) * v if v > s else a_r * s + (1 - a_r) * v; ys[i] = s
    return np.interp(np.arange(len(x)), np.arange(len(ys)) * step, ys)
presence = np.clip(smooth_follow(gate, 0.04, 0.35), 0, 1)   # 1 while talking, eases back over ~0.35 s in pauses
VO_RMS_DB = speech_db

def db(x): return 10 ** (x / 20)

# ======================= MUSIC =======================
BPM = 96.4; BEAT = 60 / BPM; BAR = 4 * BEAT
def midi(m): return 440 * 2 ** ((np.asarray(m, dtype=float) - 69) / 12)
CHORDS = [(57, [57, 60, 64]), (53, [53, 57, 60]), (48, [48, 52, 55]), (55, [55, 59, 62])]  # Am F C G
def intensity(t):
    pts = [(0, .30), (8.5, .38), (11.3, .55), (21.0, .62), (32, .75), (41, .62), (47, .68), (52, .82), (64.9, .95), (67, .9), (69.8, .85)]
    return np.interp(t, [p[0] for p in pts], [p[1] for p in pts])
music = np.zeros((N, 2))
nbars = int(np.ceil(DUR / BAR)) + 1
for b in range(nbars):
    t0 = b * BAR; root, tones = CHORDS[b % 4]; inten = float(intensity(t0 + BAR / 2))
    n = min(sec(BAR + 0.5), N - sec(t0)) if sec(t0) < N else 0
    if n <= 0: break
    # pad: detuned saws, slow attack, low-passed
    pad = np.zeros(n)
    for m in tones + [tones[0] + 12]:
        for det in (-0.07, 0, 0.08):
            f = midi(m + det) * np.ones(n); pad += saw(f) * 0.12
    pad = lp(pad, 700 + 900 * inten) * adsr(n, 0.5, 0.6, 1.5)
    place(music, stereo(pad, -0.15), t0, 0.55 * (0.4 + inten))
    # bass pulse (after the syringe intro)
    if t0 >= 10.5:
        for k in range(8):
            bt = t0 + k * BEAT / 2; nn = sec(BEAT * 0.5)
            f = midi(root - 12) * np.ones(nn); x = (np.sin(ph(f)) + 0.35 * saw(f)) * expdecay(nn, 0.16)
            place(music, lp(x, 400), bt, 0.55 * inten * (1.0 if k % 2 == 0 else 0.7))
    # plucked arpeggio (8th notes), gets busier with energy
    pat = [0, 1, 2, 1, 0, 2, 1, 2] if inten < 0.7 else [0, 1, 2, 3, 2, 1, 2, 3]
    allt = tones + [tones[0] + 12]
    for k in range(8):
        if t0 < 8 and k % 2: continue
        at = t0 + k * BEAT / 2; nn = sec(0.5); m = allt[pat[k] % len(allt)] + 12
        f = midi(m) * np.ones(nn); x = (np.sin(ph(f)) + 0.4 * np.sin(2 * ph(f)) + 0.2 * np.sin(3 * ph(f))) * expdecay(nn, 0.14)
        place(music, stereo(x, -0.4 + 0.8 * (k / 7)), at, 0.22 * (0.5 + inten))
    # percussion: soft kick, mechanical tick (hat) and metallic clank - only when the story needs energy
    for k in range(4):
        bt = t0 + k * BEAT
        if t0 >= 11.3 and (k % 2 == 0 or t0 >= 21):
            nn = sec(0.22); fr = 45 + 90 * np.exp(-np.arange(nn) / (0.03 * SR)); x = np.sin(ph(fr)) * expdecay(nn, 0.09)
            place(music, x, bt, 0.55 * inten)
        if t0 >= 21:
            for h in range(2):
                ht = bt + h * BEAT / 2; nn = sec(0.05); x = hp(noise(nn), 6500) * expdecay(nn, 0.012)
                place(music, stereo(x, 0.3), ht, 0.10 * inten * (1.0 if h == 0 else 0.6))
        if t0 >= 41 and k % 2 == 1:
            nn = sec(0.35); tt = np.arange(nn) / SR
            x = sum(np.sin(2 * np.pi * f * tt) * a for f, a in ((812, 1), (1331, .6), (2107, .4), (2899, .25))) * expdecay(nn, 0.07)
            place(music, stereo(x, 0.5), bt, 0.05 * inten)
# risers + final swell
def riser(t0, t1, g):
    n = sec(t1 - t0); x = noise(n); fc = np.linspace(400, 7000, n); y = np.zeros(n); blk = 2048
    for i in range(0, n, blk):
        c = fc[min(i, n - 1)]; y[i:i + blk] = bp(x[i:i + blk] if False else x[i:i + blk], max(100, c * 0.7), min(c * 1.4, 20000))
    y *= np.linspace(0, 1, n) ** 2; place(music, stereo(y), t0, g)
riser(40.0, 41.2, 0.10); riser(62.8, 64.99, 0.14)
n = sec(2.4); cr = hp(noise(n), 3000) * expdecay(n, 0.7); place(music, stereo(cr), 64.99, 0.10)
n = sec(1.2); tt = np.arange(n) / SR; sw = np.sin(2 * np.pi * 55 * tt) * expdecay(n, 0.5); place(music, stereo(sw), 64.99, 0.5)
fade = np.interp(TT, [0, 0.4, 66.6, 69.8], [0, 1, 1, 0]) ** 1.3          # smooth open + restrained end fade
music *= fade[:, None]
music = norm(music, 0.5)
# duck against the REAL voiceover: -23 dB below voice while talking, -14 dB in pauses, +2..3 dB lifts on reveals
music_rms_db = 20 * np.log10(np.sqrt(np.mean(music[music[:, 0] != 0] ** 2)))
boost = np.zeros(N)
for t0, g in TL['musicBoost']:
    boost += g * np.exp(-0.5 * ((TT - (t0 + 0.5)) / 0.7) ** 2)
tgt_db = (VO_RMS_DB - 21) * presence + (VO_RMS_DB - 13) * (1 - presence) + boost * (1 - presence * 0.5)
music_gain = db(tgt_db - music_rms_db)
music *= music_gain[:, None]

# ======================= SFX SYNTHESIS =======================
def s_plunger(d):
    n = sec(d); t = np.arange(n) / SR
    fric = bp(noise(n), 1400, 3200) * (0.5 + 0.5 * np.sin(2 * np.pi * 7 * t)) * 0.25
    slide = lp(noise(n), 700) * 0.5; thump = np.sin(2 * np.pi * 90 * t) * expdecay(n, 0.05) * 0.0
    x = (fric + slide) * adsr(n, 0.12, 0.18); end = np.zeros(n); k = int(max(0, n - sec(0.08))); end[k:] = np.sin(2 * np.pi * 140 * t[:n - k]) * expdecay(n - k, 0.03) * 0.6
    return norm(x + end, 0.6)
def s_liquid(d):
    n = sec(d); x = lp(noise(n), 500) * 0.15
    for _ in range(int(d * 22)):
        i = rng.integers(0, max(1, n - sec(0.08))); m = sec(0.06); f0 = rng.uniform(500, 1400); tt = np.arange(m) / SR
        x[i:i + m] += np.sin(2 * np.pi * (f0 * tt + 6000 * tt ** 2)) * expdecay(m, 0.012) * rng.uniform(0.1, 0.4)
    return norm(x * adsr(n, 0.15, 0.25), 0.5)
def s_click(d):
    n = sec(0.2); t = np.arange(n) / SR; return norm(hp(noise(n), 2500) * expdecay(n, 0.004) + np.sin(2 * np.pi * 2200 * t) * expdecay(n, 0.012), 0.8)
def s_pressure(d):
    n = sec(d); t = np.arange(n) / SR; f = np.linspace(80, 170, n); x = np.sin(ph(f)) + 0.5 * np.sin(2 * ph(f)) + 0.2 * saw(f)
    hiss = hp(noise(n), 4000) * np.linspace(0, 1, n) ** 2 * 0.25
    return norm((lp(x, 900) * 0.8 + hiss) * adsr(n, d * 0.5, 0.1), 0.6)
def s_hydext(d):
    n = sec(d); f = np.linspace(300, 520, n) + 12 * np.sin(np.linspace(0, 40, n)); x = lp(saw(f), 1600) * 0.4
    hiss = bp(noise(n), 2000, 6500) * 0.25; rum = lp(noise(n), 160) * 0.5
    return norm((x + hiss + rum) * adsr(n, 0.2, 0.3), 0.7)
def s_dig(d):
    n = sec(d); x = lp(noise(n), 2500) * 0.6 * adsr(n, 0.05, d * 0.5)
    for _ in range(int(d * 90)):
        i = rng.integers(0, n - 60); x[i:i + 40] += rng.uniform(-1, 1, 40) * rng.uniform(0.2, 0.8) * expdecay(40, 0.0006)
    t = np.arange(n) / SR; th = np.sin(2 * np.pi * 62 * t) * expdecay(n, 0.15) * 0.8
    return norm(x + th, 0.8)
def s_gravel(d):
    n = sec(d); x = np.zeros(n)
    for _ in range(int(d * 260)):
        i = int(rng.beta(1, 2.2) * (n - 80)); m = rng.integers(20, 70); f = rng.uniform(900, 4200)
        x[i:i + m] += rng.standard_normal(m) * expdecay(m, 0.0008) * rng.uniform(0.1, 0.6) * (1 - i / n)
    return norm(hp(x, 600) + lp(noise(n), 900) * 0.12 * expdecay(n, d * 0.5), 0.7)
def s_clunk(d):
    n = sec(0.45); t = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * t) * a * expdecay(n, tau) for f, a, tau in ((170, 1, 0.12), (342, .5, 0.08), (788, .35, 0.05), (1530, .2, 0.03)))
    x += bp(noise(n), 800, 4000) * expdecay(n, 0.01) * 0.6; return norm(x, 0.8)
def s_thud(d):
    n = sec(0.6); t = np.arange(n) / SR; f = 40 + 60 * np.exp(-t / 0.05); return norm(np.sin(ph(f)) * expdecay(n, 0.18) + lp(noise(n), 500) * expdecay(n, 0.05) * 0.5, 0.9)
def s_strain(d):
    n = sec(d); t = np.arange(n) / SR; wob = 1 + 0.05 * np.sin(2 * np.pi * 5.5 * t); f = (np.linspace(620, 980, n) * wob)
    x = lp(saw(f), 2400) * 0.35 * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t))
    hiss = bp(noise(n), 3000, 9000) * 0.25 * (0.5 + 0.5 * np.sin(2 * np.pi * 2.3 * t) ** 2)
    cr = np.zeros(n)
    for c in (0.7, 1.7, 2.6):
        i = sec(c); m = min(sec(0.5), n - i)
        if m > 0: tt = np.arange(m) / SR; cr[i:i + m] += bp(noise(m), 300, 900) * np.sin(2 * np.pi * (3 + 12 * tt) * tt) * expdecay(m, 0.2) * 0.8
    return norm((x + hiss + cr) * adsr(n, 0.3, 0.4), 0.8)
def s_creak(d):
    n = sec(d); t = np.arange(n) / SR; f = 180 + 120 * np.sin(2 * np.pi * 1.7 * t) + 60 * t
    return norm(bp(saw(f) * (0.5 + 0.5 * np.sin(2 * np.pi * 11 * t)) + noise(n) * 0.1, 250, 1200) * adsr(n, 0.2, 0.4), 0.5)
def s_dieselstart(d):
    n = sec(d); t = np.arange(n) / SR
    st = lp(saw(np.linspace(180, 420, n) + 0 * t), 2200) * 0.35 * (t < 0.7) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t))
    firing = np.where(t < 0.65, 8.0, 8 + 14 * np.clip((t - 0.65) / 0.7, 0, 1) ** 0.6); p = np.cumsum(firing) / SR
    pulses = (p % 1.0) < 0.0; pulse = np.zeros(n); idx = np.where(np.diff(np.floor(p)) > 0)[0]
    for i in idx:
        m = min(sec(0.06), n - i)
        if m > 0: pulse[i:i + m] += np.sin(2 * np.pi * 70 * np.arange(m) / SR) * expdecay(m, 0.02) * (1.0 if t[i] > 0.6 else 0.6)
    rum = lp(noise(n), 220) * 0.35 * np.clip((t - 0.55) / 0.5, 0, 1)
    return norm(st + pulse + rum, 0.9)
def s_whoosh(d, up=0, down=0):
    n = sec(d); x = noise(n); c0, c1 = (500, 4500) if up else ((4500, 500) if down else (700, 2500))
    fc = np.interp(np.arange(n), [0, n * 0.5, n], [c0, (c0 + c1) / 2 * 1.3, c1]); out = np.zeros(n); blk = 1024
    for i in range(0, n, blk):
        c = float(fc[min(i, n - 1)]); out[i:i + blk] = bp(x[i:i + blk], max(120, c * 0.6), min(c * 1.7, 18000), ) if False else sos('band', [max(120, c * 0.6), min(c * 1.7, 18000)], x[i:i + blk])
    e = np.sin(np.pi * np.linspace(0, 1, n) ** (0.9 if not up else 1.6)) ** 2        # peak at the cut (mid / late for 'up')
    return norm(out * e, 0.7)
def s_pop(d):
    n = sec(0.2); t = np.arange(n) / SR; f = 1100 * np.exp(-t / 0.03) + 180; return norm(np.sin(ph(f)) * expdecay(n, 0.05) + hp(noise(n), 3000) * expdecay(n, 0.004) * 0.4, 0.8)
def s_boing(d):
    n = sec(d); t = np.arange(n) / SR; f = 260 + 220 * np.exp(-t / 0.18) * np.sin(2 * np.pi * 11 * t) + 60 * np.exp(-t / 0.3)
    return norm((np.sin(ph(f)) + 0.3 * np.sin(2 * ph(f))) * expdecay(n, 0.28), 0.7)
def s_womp(d):
    n = sec(d); t = np.arange(n) / SR; f = np.interp(t, [0, 0.28, 0.32, d], [330, 262, 236, 150]) * (1 + 0.02 * np.sin(2 * np.pi * 6 * t))
    return norm(lp(signal.sawtooth(ph(f), 0.5) * 0.6 + np.sin(ph(f)), 1400) * adsr(n, 0.02, 0.25), 0.7)
def s_bonk(d):
    n = sec(d); t = np.arange(n) / SR; f = 110 * np.exp(-t / 0.18) + 42
    return norm(np.sin(ph(f)) * expdecay(n, 0.25) + bp(noise(n), 300, 1400) * expdecay(n, 0.02) * 0.7, 0.9)
def s_blip(d):
    n = sec(d); t = np.arange(n) / SR; f = np.interp(t, [0, d], [650, 1500]); return norm(np.sin(ph(f)) * adsr(n, 0.01, 0.15), 0.6)
SYN = dict(plunger=s_plunger, liquid=s_liquid, click=s_click, pressure=s_pressure, hydext=s_hydext, dig=s_dig, gravel=s_gravel, clunk=s_clunk, thud=s_thud,
           strain=s_strain, creak=s_creak, dieselstart=s_dieselstart, whoosh=s_whoosh, whoosh_up=lambda d: s_whoosh(d, up=1), whoosh_down=lambda d: s_whoosh(d, down=1),
           pop=s_pop, boing=s_boing, womp=s_womp, bonk=s_bonk, blip=s_blip)

def layer(cues):
    buf = np.zeros((N, 2))
    for c in cues:
        x = SYN[c['type']](c['dur']); pan = {'plunger': -0.2, 'liquid': 0.2}.get(c['type'], 0.0); place(buf, stereo(x, pan), c['t'], c['gain'])
    return buf
mech = layer(TL['sfx']['mech']); cam = layer(TL['sfx']['cam']); fun = layer(TL['sfx']['fun'])

# ---- continuous mechanical beds, automated from the SAME pose/flow data that drives the animation ----
def smooth_env(a, ms=60):
    k = int(ms / 1000 * SR); return np.convolve(a, np.ones(k) / k, 'same') if k > 1 else a
run = smooth_env(env_at('run', TT), 80); demand = env_at('demand', TT); pump = env_at('pump', TT)
# engine: firing pulses (~15 Hz idle, up to ~21 Hz under load) + low rumble + mid growl
rev = 15 + 6 * smooth_env(demand, 200)
pp = np.cumsum(rev) / SR; idx = np.where(np.diff(np.floor(pp)) > 0)[0]
eng = np.zeros(N); kern = np.sin(2 * np.pi * 75 * np.arange(sec(0.05)) / SR) * expdecay(sec(0.05), 0.016)
for i in idx:
    j = min(N, i + len(kern)); eng[i:j] += kern[:j - i] * rng.uniform(0.7, 1.15)
eng = lp(eng, 400) * 0.9 + lp(noise(N), 140) * 0.5 + bp(noise(N), 250, 700) * 0.12
# the engine only starts at 21.05 s in the cutaway; the dieselstart one-shot covers the first 1.6 s
eng_gate = run * np.where(TT >= 11.2, 1.0, 0.0) * np.clip((TT - 21.05) / 1.6, 0, 1) ** 0 
eng_gate = np.where((TT > 21.0) & (TT < 22.7), np.interp(TT, [21.0, 21.7, 22.7], [0, 0.3, 1]), eng_gate)
bed_eng = eng * eng_gate * 0.35
# hydraulic pump whine follows pump flow; pitch follows demand
wf = 360 + 160 * smooth_env(demand, 120)
whine = lp(saw(wf), 3000) * 0.5 + np.sin(ph(wf * 2)) * 0.2
bed_pump = whine * smooth_env(pump, 120) ** 1.5 * run * np.where(TT >= 22.5, 1.0, np.where((TT > 11.2), 0.35, 0)) * 0.18
# oil rushing in transparent pipes during cutaways
hose = env_at('hose', TT); oil = bp(noise(N), 350, 1100) * (0.6 + 0.4 * np.sin(2 * np.pi * 3.1 * TT)) * hose * np.clip(pump * 1.2, 0, 1) * 0.35
# cylinders / joints: hiss + servo proportional to each cylinder's motion; swing = low rotary growl
mv = np.maximum.reduce([np.abs(env_at(k, TT)) for k in ('boom', 'stick', 'bucket')]); mvs = smooth_env(mv, 80)
hiss = bp(noise(N), 1800, 6000) * mvs * 0.25
joint = bp(noise(N), 200, 800) * mvs * (0.5 + 0.5 * np.sin(2 * np.pi * 13 * TT)) * 0.2
sw = np.abs(env_at('swing', TT)); swing = lp(saw(70 + 30 * sw), 500) * smooth_env(sw, 100) * 0.35
# track motor hum + steel track clanks at the real link rate (speed / link pitch 0.2 m)
spd = smooth_env(np.abs(env_at('travelSpeed', TT)), 120)
tm = (np.sin(ph(55 + 30 * spd)) + 0.4 * saw(55 + 30 * spd)) * spd * 0.25
rate = spd / 0.2; tp = np.cumsum(rate) / SR; tidx = np.where(np.diff(np.floor(tp)) > 0)[0]
clank = np.zeros(N); kc = sum(np.sin(2 * np.pi * f * np.arange(sec(0.08)) / SR) * a for f, a in ((380, 1), (910, .6), (1740, .3))) * expdecay(sec(0.08), 0.02)
for i in tidx:
    j = min(N, i + len(kc)); clank[i:j] += kc[:j - i] * rng.uniform(0.5, 1.0)
clank = clank * 0.22 + hp(noise(N), 5000) * spd * 0.03
beds = bed_eng + bed_pump + oil + hiss + joint + swing + tm + clank
mech += stereo(beds, 0.0) * 1.0

# ---------------- level staging and ducking for SFX ----------------
def level_to(x, target_db, mask=None):
    m = np.abs(x).max(axis=1) > 1e-6 if mask is None else mask; r = np.sqrt(np.mean(x[m] ** 2)); return x * db(target_db - 20 * np.log10(r))
duck_sfx = db(-4.0 * presence)           # SFX tuck 4 dB under speech
def peak_to(x, p): return x * (p / (np.abs(x).max() or 1))
mech = level_to(mech, VO_RMS_DB - 17); mech = np.tanh(mech / 0.28) * 0.28   # soft limit: no spikes
mech = mech * duck_sfx[:, None]
cam = peak_to(cam, 0.17) * duck_sfx[:, None]                                # whooshes: clearly audible, ~12 dB under voice peaks
fun = peak_to(fun, 0.20) * db(-3.0 * presence)[:, None]                     # funny SFX: brief, sit in the narration pauses
for name, x in (('music', music), ('mech', mech), ('cam', cam), ('fun', fun)):
    f = np.minimum(1, TT / 0.01)[:, None] * np.minimum(1, (DUR - TT) / 0.05)[:, None]; x *= f
# prevent summing above full scale with the (untouched) voiceover
mix = music + mech + cam + fun + vo[:, None]
peak = np.abs(mix).max()
if peak > 0.93:
    k = 0.93 / peak
    for x in (music, mech, cam, fun): x *= k
    mix = music + mech + cam + fun + vo[:, None]
def write(name, x):
    wav = f'{ROOT}/public/audio/{name}.wav'; import wave
    pcm = (np.clip(x, -1, 1) * 32767).astype('<i2')
    with wave.open(wav, 'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', wav, '-codec:a', 'libmp3lame', '-b:a', '192k', f'{ROOT}/public/audio/{name}.mp3'], check=True); os.remove(wav)
write('music', music); write('sfx_mechanical', mech); write('sfx_camera', cam); write('sfx_funny', fun)
write('mixdown_preview', np.stack([mix[:, 0], mix[:, 0]], 1) if mix.ndim == 1 else mix)
rep = {'voice_speech_rms_db': round(float(VO_RMS_DB), 2), 'duration_s': DUR, 'mix_peak': round(float(np.abs(mix).max()), 3)}
for n_, x in (('music', music), ('mech', mech), ('cam', cam), ('fun', fun)):
    sp = presence > 0.9; rep[n_ + '_rms_db_speech'] = round(float(20 * np.log10(np.sqrt(np.mean(x[sp] ** 2)) + 1e-9)), 2); rep[n_ + '_rms_db_pause'] = round(float(20 * np.log10(np.sqrt(np.mean(x[presence < 0.1] ** 2)) + 1e-9)), 2); rep[n_ + '_peak'] = round(float(np.abs(x).max()), 3)
json.dump(rep, open(f'{ROOT}/public/audio/audio_report.json', 'w'), indent=1); print(json.dumps(rep, indent=1))
