// Regenerates src/data/envelopes.json (hydraulic activity per 20 ms) from the SAME pose/camera code the video uses.
// Needs the dev dependency tree (esbuild ships with @remotion/cli). Run: node scripts/export_envelopes.mjs
import { build } from 'esbuild';
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
await build({ entryPoints: ['scripts/envelopes_entry.ts'], bundle: true, platform: 'node', format: 'cjs', outfile: '.tmp_env.cjs', logLevel: 'error', loader: { '.json': 'json' } });
const out = execFileSync('node', ['.tmp_env.cjs'], { maxBuffer: 1 << 28 }).toString();
writeFileSync('src/data/envelopes.json', out);
console.log('wrote src/data/envelopes.json');
