# Hydraulic Excavator — 3D YouTube Short (Remotion)

1080 × 1920, 30 fps, **2094 frames = 69.80 s** (your voiceover is 69.79 s and is the master timeline).
Composition ID: `HydraulicExcavator`. No captions, no on-screen text, no hook text.

## Render on GitHub (phone friendly)
1. Create a repo and upload the **contents** of this ZIP (keep the folder structure; the `.github` folder must be included).
2. GitHub → **Actions → Render Hydraulic Excavator Short → Run workflow**.
   - First run with `frames` = `0-89` to test 3 seconds (a few minutes).
   - Then run again with `frames` empty for the full video.
3. Download `hydraulic-excavator-short` from the run's **Artifacts**.

Local: `npm install` → `npm run start` (preview) → `npm run render` (output `out/hydraulic-excavator.mp4`).
Rendering is CPU/software-GL (`--gl=angle`); expect roughly 1–3 hours for the full video on a free runner.

## Project map
- `src/data/timeline.json` — **single source of truth**: sentence windows detected from your audio, pose keyframes, SFX cues.
- `src/data/envelopes.json` — hydraulic activity (per 20 ms) exported from the same pose code; drives SFX beds.
- `src/kinematics.ts` — real excavator linkage: boom/stick/bucket from pin geometry, 4-bar bucket linkage; **cylinder lengths and strokes are computed from the pins**, so rods extend exactly as the arm needs.
- `src/world.ts`, `src/camera.ts` — machine state + camera director (37 shots, every shot orbits a live anchor so framing never breaks).
- `src/cutaways.ts` — when covers/cylinders/hoses/gearbox turn transparent, and the signed oil flow per cylinder.
- `src/world/*` — models: syringes + tube + jack/car, excavator (arm, cylinders, hoses), power pack (engine, swash-plate pump, tank, control valve, pilot lines), cab + joysticks + hands, undercarriage (48-link tracks, sprocket, travel motor, planetary gearbox), site, dust/soil effects.
- `scripts/audio_gen.py` — regenerates all audio from the real voiceover. `npm run audio`.
- `scripts/export_envelopes.mjs` — regenerates `envelopes.json` after editing poses. `scripts/verify.mjs` — `npm run verify`.

## Audio layers (separate files in `public/audio/`)
`voiceover.mp3` (untouched, volume 1) · `music.mp3` (original synthesized score, ducked from your actual voice envelope: ≈21 dB below speech, ≈13 dB in pauses, small lifts at reveals, fade-out) · `sfx_mechanical.mp3` · `sfx_camera.mp3` (21 whooshes whose peaks land on camera cuts) · `sfx_funny.mp3` (6 short gags, all in narration pauses). `mixdown_preview.mp3` is a listen-only mix. `audio_report.json` has measured levels (mix peak 0.65, no clipping).

## Hydraulic accuracy
Reservoir → pump → control valve → cylinder (cap/rod chambers) → return → reservoir. Joysticks drive **pilot lines** (thin cyan) to the valve; they never pump the main oil. The counterweight is shown as balancing within limits, not preventing tipping.

## Honest status
See the chat summary: code was syntax-checked and the math/timeline/camera/audio were executed, but the 3D scene was **not rendered** in the authoring environment (no network → Remotion/three could not be installed). Run the 0-89 test first.
